﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.lblGreyBackgrd = New System.Windows.Forms.Label()
        Me.lblRBC_ClientIdentification = New System.Windows.Forms.Label()
        Me.lblStep1 = New System.Windows.Forms.Label()
        Me.lblStep2 = New System.Windows.Forms.Label()
        Me.lblStep3 = New System.Windows.Forms.Label()
        Me.lblStep4 = New System.Windows.Forms.Label()
        Me.lblHeader2 = New System.Windows.Forms.Label()
        Me.optClientCard = New System.Windows.Forms.RadioButton()
        Me.optCreditCard = New System.Windows.Forms.RadioButton()
        Me.lblInstruct1 = New System.Windows.Forms.Label()
        Me.txtClientCardNum = New System.Windows.Forms.TextBox()
        Me.lblInstructClientCardNum = New System.Windows.Forms.Label()
        Me.lblInstructDigitIssueNum = New System.Windows.Forms.Label()
        Me.lblInstructCCNum = New System.Windows.Forms.Label()
        Me.txtDigitIssueNum = New System.Windows.Forms.TextBox()
        Me.txtCCNumConfirm = New System.Windows.Forms.TextBox()
        Me.lblInstruct2 = New System.Windows.Forms.Label()
        Me.lblFooter = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnContinue = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.picClientCard = New System.Windows.Forms.PictureBox()
        Me.picCreditCard = New System.Windows.Forms.PictureBox()
        Me.ttpMain = New System.Windows.Forms.ToolTip(Me.components)
        CType(Me.picClientCard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCreditCard, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.BackColor = System.Drawing.SystemColors.Menu
        Me.lblHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.Location = New System.Drawing.Point(12, 9)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(81, 16)
        Me.lblHeader.TabIndex = 1
        Me.lblHeader.Text = "Step 1 to 4"
        '
        'lblGreyBackgrd
        '
        Me.lblGreyBackgrd.BackColor = System.Drawing.SystemColors.Menu
        Me.lblGreyBackgrd.Location = New System.Drawing.Point(3, 3)
        Me.lblGreyBackgrd.Name = "lblGreyBackgrd"
        Me.lblGreyBackgrd.Size = New System.Drawing.Size(207, 528)
        Me.lblGreyBackgrd.TabIndex = 2
        '
        'lblRBC_ClientIdentification
        '
        Me.lblRBC_ClientIdentification.AutoSize = True
        Me.lblRBC_ClientIdentification.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRBC_ClientIdentification.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lblRBC_ClientIdentification.Location = New System.Drawing.Point(216, 35)
        Me.lblRBC_ClientIdentification.Name = "lblRBC_ClientIdentification"
        Me.lblRBC_ClientIdentification.Size = New System.Drawing.Size(208, 24)
        Me.lblRBC_ClientIdentification.TabIndex = 3
        Me.lblRBC_ClientIdentification.Text = "RBC Client Identification"
        '
        'lblStep1
        '
        Me.lblStep1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStep1.Location = New System.Drawing.Point(-2, 32)
        Me.lblStep1.Name = "lblStep1"
        Me.lblStep1.Size = New System.Drawing.Size(212, 32)
        Me.lblStep1.TabIndex = 4
        Me.lblStep1.Text = "1.  RBC Client Identification"
        Me.lblStep1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStep2
        '
        Me.lblStep2.BackColor = System.Drawing.SystemColors.Menu
        Me.lblStep2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStep2.Location = New System.Drawing.Point(12, 72)
        Me.lblStep2.Name = "lblStep2"
        Me.lblStep2.Size = New System.Drawing.Size(198, 32)
        Me.lblStep2.TabIndex = 4
        Me.lblStep2.Text = "2.  Personal and Product" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Security Questions"
        Me.lblStep2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblStep3
        '
        Me.lblStep3.BackColor = System.Drawing.SystemColors.Menu
        Me.lblStep3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStep3.Location = New System.Drawing.Point(12, 114)
        Me.lblStep3.Name = "lblStep3"
        Me.lblStep3.Size = New System.Drawing.Size(198, 32)
        Me.lblStep3.TabIndex = 4
        Me.lblStep3.Text = "3.  Online Banking Profile Setup"
        Me.lblStep3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblStep4
        '
        Me.lblStep4.BackColor = System.Drawing.SystemColors.Menu
        Me.lblStep4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStep4.Location = New System.Drawing.Point(12, 157)
        Me.lblStep4.Name = "lblStep4"
        Me.lblStep4.Size = New System.Drawing.Size(198, 32)
        Me.lblStep4.TabIndex = 4
        Me.lblStep4.Text = "4.  Congratulations"
        Me.lblStep4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblHeader2
        '
        Me.lblHeader2.BackColor = System.Drawing.SystemColors.Window
        Me.lblHeader2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader2.Location = New System.Drawing.Point(226, 72)
        Me.lblHeader2.Name = "lblHeader2"
        Me.lblHeader2.Size = New System.Drawing.Size(542, 45)
        Me.lblHeader2.TabIndex = 4
        Me.lblHeader2.Text = "Please select one of the RBC product/services you have with us so we can identift" &
    "y you:"
        Me.lblHeader2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'optClientCard
        '
        Me.optClientCard.AutoSize = True
        Me.optClientCard.Checked = True
        Me.optClientCard.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optClientCard.Location = New System.Drawing.Point(229, 126)
        Me.optClientCard.Name = "optClientCard"
        Me.optClientCard.Size = New System.Drawing.Size(91, 20)
        Me.optClientCard.TabIndex = 0
        Me.optClientCard.TabStop = True
        Me.optClientCard.Text = "Client Card"
        Me.optClientCard.UseVisualStyleBackColor = True
        '
        'optCreditCard
        '
        Me.optCreditCard.AutoSize = True
        Me.optCreditCard.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optCreditCard.Location = New System.Drawing.Point(229, 157)
        Me.optCreditCard.Name = "optCreditCard"
        Me.optCreditCard.Size = New System.Drawing.Size(301, 20)
        Me.optCreditCard.TabIndex = 1
        Me.optCreditCard.Text = "Credit Card (Any RBC Royal Bank Credit Card)"
        Me.optCreditCard.UseVisualStyleBackColor = True
        '
        'lblInstruct1
        '
        Me.lblInstruct1.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstruct1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstruct1.Location = New System.Drawing.Point(226, 195)
        Me.lblInstruct1.Name = "lblInstruct1"
        Me.lblInstruct1.Size = New System.Drawing.Size(542, 45)
        Me.lblInstruct1.TabIndex = 4
        Me.lblInstruct1.Text = "Please complete the fields below with the information displayed on your Client Ca" &
    "rd:"
        Me.lblInstruct1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtClientCardNum
        '
        Me.txtClientCardNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtClientCardNum.Location = New System.Drawing.Point(509, 273)
        Me.txtClientCardNum.Name = "txtClientCardNum"
        Me.txtClientCardNum.Size = New System.Drawing.Size(232, 26)
        Me.txtClientCardNum.TabIndex = 2
        Me.ttpMain.SetToolTip(Me.txtClientCardNum, "Enter Client Card Number - numeric value only!")
        '
        'lblInstructClientCardNum
        '
        Me.lblInstructClientCardNum.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstructClientCardNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructClientCardNum.Location = New System.Drawing.Point(506, 247)
        Me.lblInstructClientCardNum.Name = "lblInstructClientCardNum"
        Me.lblInstructClientCardNum.Size = New System.Drawing.Size(152, 29)
        Me.lblInstructClientCardNum.TabIndex = 4
        Me.lblInstructClientCardNum.Text = "Client Card Number:"
        Me.lblInstructClientCardNum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblInstructDigitIssueNum
        '
        Me.lblInstructDigitIssueNum.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstructDigitIssueNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructDigitIssueNum.Location = New System.Drawing.Point(506, 304)
        Me.lblInstructDigitIssueNum.Name = "lblInstructDigitIssueNum"
        Me.lblInstructDigitIssueNum.Size = New System.Drawing.Size(161, 29)
        Me.lblInstructDigitIssueNum.TabIndex = 4
        Me.lblInstructDigitIssueNum.Text = "2-Digit Issues Number:"
        Me.lblInstructDigitIssueNum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblInstructCCNum
        '
        Me.lblInstructCCNum.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstructCCNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructCCNum.Location = New System.Drawing.Point(506, 361)
        Me.lblInstructCCNum.Name = "lblInstructCCNum"
        Me.lblInstructCCNum.Size = New System.Drawing.Size(235, 29)
        Me.lblInstructCCNum.TabIndex = 4
        Me.lblInstructCCNum.Text = "Client Card Number (Confirmation):"
        Me.lblInstructCCNum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtDigitIssueNum
        '
        Me.txtDigitIssueNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDigitIssueNum.Location = New System.Drawing.Point(509, 330)
        Me.txtDigitIssueNum.Name = "txtDigitIssueNum"
        Me.txtDigitIssueNum.Size = New System.Drawing.Size(232, 26)
        Me.txtDigitIssueNum.TabIndex = 3
        Me.ttpMain.SetToolTip(Me.txtDigitIssueNum, "Enter Digit Issues Number - numeric value only!")
        '
        'txtCCNumConfirm
        '
        Me.txtCCNumConfirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCCNumConfirm.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtCCNumConfirm.Location = New System.Drawing.Point(509, 387)
        Me.txtCCNumConfirm.Name = "txtCCNumConfirm"
        Me.txtCCNumConfirm.Size = New System.Drawing.Size(232, 26)
        Me.txtCCNumConfirm.TabIndex = 4
        Me.ttpMain.SetToolTip(Me.txtCCNumConfirm, "Enter matching Client Card Number - numeric value only!")
        '
        'lblInstruct2
        '
        Me.lblInstruct2.BackColor = System.Drawing.SystemColors.Window
        Me.lblInstruct2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstruct2.Location = New System.Drawing.Point(506, 412)
        Me.lblInstruct2.Name = "lblInstruct2"
        Me.lblInstruct2.Size = New System.Drawing.Size(235, 29)
        Me.lblInstruct2.TabIndex = 4
        Me.lblInstruct2.Text = "(16 digits - do not include your transit number)"
        Me.lblInstruct2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFooter
        '
        Me.lblFooter.BackColor = System.Drawing.SystemColors.Window
        Me.lblFooter.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFooter.Location = New System.Drawing.Point(217, 441)
        Me.lblFooter.Name = "lblFooter"
        Me.lblFooter.Size = New System.Drawing.Size(542, 36)
        Me.lblFooter.TabIndex = 4
        Me.lblFooter.Text = "Please complete the above to proceed to Step 2."
        Me.lblFooter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnBack.Enabled = False
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.Navy
        Me.btnBack.Location = New System.Drawing.Point(220, 480)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(100, 31)
        Me.btnBack.TabIndex = 8
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'btnContinue
        '
        Me.btnContinue.BackColor = System.Drawing.Color.DarkBlue
        Me.btnContinue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnContinue.ForeColor = System.Drawing.Color.White
        Me.btnContinue.Location = New System.Drawing.Point(324, 480)
        Me.btnContinue.Name = "btnContinue"
        Me.btnContinue.Size = New System.Drawing.Size(100, 31)
        Me.btnContinue.TabIndex = 5
        Me.btnContinue.Text = "Continue"
        Me.btnContinue.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Navy
        Me.btnCancel.Location = New System.Drawing.Point(641, 480)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(100, 31)
        Me.btnCancel.TabIndex = 6
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'picClientCard
        '
        Me.picClientCard.Image = Global.RBC_DebitCard.My.Resources.Resources.RBC_ClientCardx300
        Me.picClientCard.Location = New System.Drawing.Point(222, 233)
        Me.picClientCard.Name = "picClientCard"
        Me.picClientCard.Size = New System.Drawing.Size(281, 180)
        Me.picClientCard.TabIndex = 6
        Me.picClientCard.TabStop = False
        '
        'picCreditCard
        '
        Me.picCreditCard.Image = Global.RBC_DebitCard.My.Resources.Resources.rbc_rewards_visa_plus
        Me.picCreditCard.Location = New System.Drawing.Point(222, 233)
        Me.picCreditCard.Name = "picCreditCard"
        Me.picCreditCard.Size = New System.Drawing.Size(281, 178)
        Me.picCreditCard.TabIndex = 6
        Me.picCreditCard.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(772, 535)
        Me.Controls.Add(Me.btnContinue)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.txtCCNumConfirm)
        Me.Controls.Add(Me.txtDigitIssueNum)
        Me.Controls.Add(Me.txtClientCardNum)
        Me.Controls.Add(Me.picClientCard)
        Me.Controls.Add(Me.picCreditCard)
        Me.Controls.Add(Me.optCreditCard)
        Me.Controls.Add(Me.optClientCard)
        Me.Controls.Add(Me.lblFooter)
        Me.Controls.Add(Me.lblInstruct1)
        Me.Controls.Add(Me.lblInstruct2)
        Me.Controls.Add(Me.lblInstructCCNum)
        Me.Controls.Add(Me.lblInstructDigitIssueNum)
        Me.Controls.Add(Me.lblInstructClientCardNum)
        Me.Controls.Add(Me.lblHeader2)
        Me.Controls.Add(Me.lblStep4)
        Me.Controls.Add(Me.lblStep3)
        Me.Controls.Add(Me.lblStep2)
        Me.Controls.Add(Me.lblStep1)
        Me.Controls.Add(Me.lblRBC_ClientIdentification)
        Me.Controls.Add(Me.lblHeader)
        Me.Controls.Add(Me.lblGreyBackgrd)
        Me.Name = "frmMain"
        Me.Text = "RBC Client Debit Card"
        CType(Me.picClientCard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCreditCard, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblHeader As Label
    Friend WithEvents lblGreyBackgrd As Label
    Friend WithEvents lblRBC_ClientIdentification As Label
    Friend WithEvents lblStep1 As Label
    Friend WithEvents lblStep2 As Label
    Friend WithEvents lblStep3 As Label
    Friend WithEvents lblStep4 As Label
    Friend WithEvents lblHeader2 As Label
    Friend WithEvents optClientCard As RadioButton
    Friend WithEvents optCreditCard As RadioButton
    Friend WithEvents lblInstruct1 As Label
    Friend WithEvents picClientCard As PictureBox
    Friend WithEvents txtClientCardNum As TextBox
    Friend WithEvents lblInstructClientCardNum As Label
    Friend WithEvents lblInstructDigitIssueNum As Label
    Friend WithEvents lblInstructCCNum As Label
    Friend WithEvents txtDigitIssueNum As TextBox
    Friend WithEvents txtCCNumConfirm As TextBox
    Friend WithEvents lblInstruct2 As Label
    Friend WithEvents lblFooter As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents btnContinue As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents picCreditCard As PictureBox
    Friend WithEvents ttpMain As ToolTip
End Class
