﻿
''' <summary>
''' RBC Client Card Indentification
''' Created: Joseph Jean-Charles on 2020-03-13
''' Copyright 2020 All rights Reserved.
''' </summary>
Public Class frmMain
    ''' <summary>
    ''' Change RBC Card to Client Card
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub optClientCard_CheckedChanged(sender As Object, e As EventArgs) Handles optClientCard.CheckedChanged
        If optClientCard.Checked Then
            picClientCard.Visible = True
            lblInstructClientCardNum.Text = "Client Card Number:"
            lblInstructCCNum.Text = "Client Card Number (Confirmation):"
            lblInstruct1.Text = "Please complete the fields below with the information displayed on your Client Card:"
        Else
            picClientCard.Visible = False
        End If
    End Sub
    ''' <summary>
    ''' Change RBC Card to Credit Card
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub optCreditCard_CheckedChanged(sender As Object, e As EventArgs) Handles optCreditCard.CheckedChanged
        If optCreditCard.Checked Then
            picCreditCard.Visible = True
            lblInstructClientCardNum.Text = "Credit Card Number:"
            lblInstructCCNum.Text = "Credit Card Number (Confirmation):"
            lblInstruct1.Text = "Please complete the fields below with the information displayed on your Credit Card:"
        Else
            picCreditCard.Visible = False
        End If
    End Sub
    ''' <summary>
    ''' Reset user textboxes and enable property
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        txtCCNumConfirm.Clear()
        txtClientCardNum.Clear()
        txtDigitIssueNum.Clear()

        txtDigitIssueNum.Enabled = True
        txtClientCardNum.Enabled = True
        txtCCNumConfirm.Enabled = True

        picClientCard.Visible = True
        picCreditCard.Visible = False
        optClientCard.Checked = True

        lblFooter.Text = slblFooter

        iIncorrectInput = 0

        txtClientCardNum.Select()
    End Sub
    ''' <summary>
    ''' Check that textboxes are not empty, values are numeric
    ''' Warn if not numeric, count incorrect input - if exceeds 3 attempts
    ''' Disable and Clear textboxes
    ''' Check Client Card Nubmer is correct - matches, allow to proceed to step 2
    ''' Replace message for correctly completed MessageBox by placeholders 'CCN and 'DIN' with corresponding values from iClientCardNum and iDigitIssuesNum
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnContinue_Click(sender As Object, e As EventArgs) Handles btnContinue.Click


        If txtClientCardNum.Text <> "" Then

            Try
                iClientCardNum = Int64.Parse(txtClientCardNum.Text)
            Catch ex As Exception
                MessageBox.Show(sWarningMesageNumeric, sWarningTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End Try

        Else
            MessageBox.Show(sWarningMsgClientCrdEmpty, sWarningTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtClientCardNum.Select()
            Exit Sub
        End If

        If txtDigitIssueNum.Text <> "" Then

            Try
                iDigitIssueNum = Integer.Parse(txtDigitIssueNum.Text)
            Catch ex As Exception
                MessageBox.Show(sWarningMesageNumeric, sWarningTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End Try

        Else
            MessageBox.Show(sWarningMsDigitIssueEmpty, sWarningTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtDigitIssueNum.Select()
            Exit Sub
        End If

        If txtCCNumConfirm.Text <> "" Then

            Try
                iCCNumConfirm = Int64.Parse(txtCCNumConfirm.Text)
            Catch ex As Exception
                MessageBox.Show(sWarningMesageNumeric, sWarningTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End Try

        Else
            MessageBox.Show(sWarningMsgCCrdEmpty, sWarningTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtCCNumConfirm.Select()
            Exit Sub
        End If

        If iClientCardNum <> iCCNumConfirm Then
            If iIncorrectInput >= 3 Then

                txtCCNumConfirm.Clear()
                txtClientCardNum.Clear()
                txtDigitIssueNum.Clear()

                txtDigitIssueNum.Enabled = False
                txtClientCardNum.Enabled = False
                txtCCNumConfirm.Enabled = False

                iIncorrectInput = 0

                MessageBox.Show(sWarningMsgExceedMaxError, sWarningTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                iIncorrectInput += 1
                MessageBox.Show(sWarningMsgCCrdMatch, sWarningTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If
        Else
            sWarningMsgCCrdComplete = sWarningMsgCCrdComplete.Replace("CCN", iClientCardNum.ToString)
            sWarningMsgCCrdComplete = sWarningMsgCCrdComplete.Replace("DIN", iDigitIssueNum.ToString)
            ans = MessageBox.Show(sWarningMsgCCrdComplete, sWarningTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)

            If ans = DialogResult.Yes Then
                lblFooter.Text = slblFooterComplete
            End If
        End If

    End Sub
    ''' <summary>
    ''' Preselect Client Card Number textbox
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtClientCardNum.Select()
    End Sub
End Class
