﻿Module mdlMain
    Public iClientCardNum As Int64
    Public iCCNumConfirm As Int64
    Public iDigitIssueNum As Integer
    Public iIncorrectInput As Integer

    Public ans As DialogResult

    Public sWarningMesageNumeric As String = "Please use only numeric values, Max 16!"
    Public sWarningMsgClientCrdEmpty As String = "Please provide Client Card Number!"
    Public sWarningMsDigitIssueEmpty As String = "Digit Issues Number is empty!"
    Public sWarningMsgCCrdEmpty As String = "Client Card Number confirmation is empty!"
    Public sWarningMsgCCrdMatch As String = "Client Card Numbers do not match!"

    Public sWarningMsgCCrdComplete As String = "Client Identification for  card number:CCN" & ControlChars.NewLine & "with Digit issues number:DIN." & ControlChars.NewLine & " Do you want to proceed to Step 2?"

    Public sWarningMsgExceedMaxError As String = "Number of attempts exceeded 3, input disabled!" & ControlChars.NewLine & "Use Cancel button to reset and try again!"

    Public sWarningTitle As String = "Client Card Indentification"

    Public slblFooter As String = "Please complete the above to proceed to Step 2."
    Public slblFooterComplete As String = "Congratulations, please proceed to Step 2!"
End Module
