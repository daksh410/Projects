﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblBitdefender = New System.Windows.Forms.Label()
        Me.lblCreateAccount = New System.Windows.Forms.Label()
        Me.txtFullname = New System.Windows.Forms.TextBox()
        Me.txtEmailAddress = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.chkAgree = New System.Windows.Forms.CheckBox()
        Me.btnCreateAccount = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.lblPrivacyPolicy = New System.Windows.Forms.Label()
        Me.lblAlready = New System.Windows.Forms.Label()
        Me.lblWarning = New System.Windows.Forms.Label()
        Me.ttpMain = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblBitdefender
        '
        Me.lblBitdefender.AutoSize = True
        Me.lblBitdefender.Font = New System.Drawing.Font("Microsoft Sans Serif", 23.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBitdefender.Location = New System.Drawing.Point(87, 35)
        Me.lblBitdefender.Name = "lblBitdefender"
        Me.lblBitdefender.Size = New System.Drawing.Size(184, 35)
        Me.lblBitdefender.TabIndex = 8
        Me.lblBitdefender.Text = "Bitdefender"
        '
        'lblCreateAccount
        '
        Me.lblCreateAccount.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCreateAccount.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblCreateAccount.Location = New System.Drawing.Point(90, 89)
        Me.lblCreateAccount.Name = "lblCreateAccount"
        Me.lblCreateAccount.Size = New System.Drawing.Size(163, 19)
        Me.lblCreateAccount.TabIndex = 9
        Me.lblCreateAccount.Text = "CREATE ACCOUNT"
        '
        'txtFullname
        '
        Me.txtFullname.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFullname.Location = New System.Drawing.Point(93, 121)
        Me.txtFullname.Name = "txtFullname"
        Me.txtFullname.Size = New System.Drawing.Size(301, 23)
        Me.txtFullname.TabIndex = 0
        '
        'txtEmailAddress
        '
        Me.txtEmailAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmailAddress.Location = New System.Drawing.Point(93, 167)
        Me.txtEmailAddress.Name = "txtEmailAddress"
        Me.txtEmailAddress.Size = New System.Drawing.Size(301, 23)
        Me.txtEmailAddress.TabIndex = 1
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword.Location = New System.Drawing.Point(93, 226)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(301, 23)
        Me.txtPassword.TabIndex = 2
        Me.ttpMain.SetToolTip(Me.txtPassword, "Please enter only numerical value")
        '
        'chkAgree
        '
        Me.chkAgree.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkAgree.Location = New System.Drawing.Point(93, 270)
        Me.chkAgree.Name = "chkAgree"
        Me.chkAgree.Size = New System.Drawing.Size(256, 24)
        Me.chkAgree.TabIndex = 3
        Me.chkAgree.Text = "I agree with the Terms of Use"
        Me.chkAgree.UseVisualStyleBackColor = True
        '
        'btnCreateAccount
        '
        Me.btnCreateAccount.AutoSize = True
        Me.btnCreateAccount.BackColor = System.Drawing.SystemColors.Highlight
        Me.btnCreateAccount.Enabled = False
        Me.btnCreateAccount.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateAccount.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.btnCreateAccount.Location = New System.Drawing.Point(93, 319)
        Me.btnCreateAccount.Name = "btnCreateAccount"
        Me.btnCreateAccount.Size = New System.Drawing.Size(178, 39)
        Me.btnCreateAccount.TabIndex = 4
        Me.btnCreateAccount.Text = "CREATE ACCOUNT"
        Me.btnCreateAccount.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.AutoSize = True
        Me.btnCancel.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.btnCancel.Location = New System.Drawing.Point(302, 319)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(92, 39)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'lblPrivacyPolicy
        '
        Me.lblPrivacyPolicy.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrivacyPolicy.ForeColor = System.Drawing.SystemColors.Highlight
        Me.lblPrivacyPolicy.Location = New System.Drawing.Point(161, 388)
        Me.lblPrivacyPolicy.Name = "lblPrivacyPolicy"
        Me.lblPrivacyPolicy.Size = New System.Drawing.Size(110, 19)
        Me.lblPrivacyPolicy.TabIndex = 6
        Me.lblPrivacyPolicy.Text = "Privacy Policy"
        '
        'lblAlready
        '
        Me.lblAlready.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAlready.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblAlready.Location = New System.Drawing.Point(90, 423)
        Me.lblAlready.Name = "lblAlready"
        Me.lblAlready.Size = New System.Drawing.Size(301, 19)
        Me.lblAlready.TabIndex = 7
        Me.lblAlready.Text = "Already have an account? Sign in"
        '
        'lblWarning
        '
        Me.lblWarning.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWarning.ForeColor = System.Drawing.Color.Red
        Me.lblWarning.Location = New System.Drawing.Point(93, 207)
        Me.lblWarning.Name = "lblWarning"
        Me.lblWarning.Size = New System.Drawing.Size(301, 16)
        Me.lblWarning.TabIndex = 10
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(499, 506)
        Me.Controls.Add(Me.lblWarning)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnCreateAccount)
        Me.Controls.Add(Me.chkAgree)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtEmailAddress)
        Me.Controls.Add(Me.txtFullname)
        Me.Controls.Add(Me.lblAlready)
        Me.Controls.Add(Me.lblPrivacyPolicy)
        Me.Controls.Add(Me.lblCreateAccount)
        Me.Controls.Add(Me.lblBitdefender)
        Me.Name = "frmMain"
        Me.Text = "Bitdefender"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBitdefender As Label
    Friend WithEvents lblCreateAccount As Label
    Friend WithEvents txtFullname As TextBox
    Friend WithEvents txtEmailAddress As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents chkAgree As CheckBox
    Friend WithEvents btnCreateAccount As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents lblPrivacyPolicy As Label
    Friend WithEvents lblAlready As Label
    Friend WithEvents lblWarning As Label
    Friend WithEvents ttpMain As ToolTip
End Class
