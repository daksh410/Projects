﻿''' <summary>
'''
''' </summary>




Public Class frmMain
    ''' <summary>
    ''' Enable Create Account Button
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub chkAgree_CheckedChanged(sender As Object, e As EventArgs) Handles chkAgree.CheckedChanged
        btnCreateAccount.Enabled = True
        bAgree = True
    End Sub

    ''' <summary>
    ''' Clear user input, reset default value
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        txtFullname.Text = sDfltFullname
        txtEmailAddress.Text = sDfltEmailAddress
        txtPassword.Text = sDfltPassword

        btnCreateAccount.Enabled = False

    End Sub

    ''' <summary>
    ''' Validate the password input, present confirmation of user
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnCreateAccount_Click(sender As Object, e As EventArgs) Handles btnCreateAccount.Click
        Try
            iPassword = Integer.Parse(txtPassword.Text)

            MessageBox.Show("Are you sure you want to create account?", "Logged in", MessageBoxButtons.OK, MessageBoxIcon.Question)

        Catch ex As Exception
            lblWarning.Text = "Please enter only numerical value"
            MessageBox.Show("Please enter only numerical value", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

        If (sFullname = txtFullname.Text And sEmailAddress = txtEmailAddress.Text) Then
            MessageBox.Show("Are you sure you want to create account?", "Logged in", MessageBoxButtons.OK, MessageBoxIcon.Question)
        Else
            MessageBox.Show("Please enter only numerical value", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    ''' <summary>
    ''' Preset the value for bitdefender
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblCreateAccount.Text = sMessage
        txtFullname.Text = sDfltFullname
        txtEmailAddress.Text = sDfltEmailAddress
    End Sub
End Class
