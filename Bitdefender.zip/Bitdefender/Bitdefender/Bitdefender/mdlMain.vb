﻿Module mdlMain
    Public Const sMessage As String = "Create Account"
    Public sOutput As String
    Public sFullname As String
    Public sEmailAddress As String
    Public iPassword As Integer
    Public bAgree As Boolean
    Public sDfltPassword As String = "Password"
    Public sDfltFullname As String = "Fullname"
    Public sDfltEmailAddress As String = "E-mail Address"
End Module
