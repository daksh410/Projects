﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblOrder = New System.Windows.Forms.Label()
        Me.lblProduct = New System.Windows.Forms.Label()
        Me.optBcnKing = New System.Windows.Forms.RadioButton()
        Me.lblVote = New System.Windows.Forms.Label()
        Me.picDblCheese = New System.Windows.Forms.PictureBox()
        Me.ctxMain = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ctxVote = New System.Windows.Forms.ToolStripMenuItem()
        Me.ctxDesignStmnt = New System.Windows.Forms.ToolStripMenuItem()
        Me.ctxSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.ctxExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.ctxSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ctxTxtCol = New System.Windows.Forms.ToolStripMenuItem()
        Me.ctxBckCol = New System.Windows.Forms.ToolStripMenuItem()
        Me.ctxFont = New System.Windows.Forms.ToolStripMenuItem()
        Me.picBcnKing = New System.Windows.Forms.PictureBox()
        Me.picIcon = New System.Windows.Forms.PictureBox()
        Me.optDblCheese = New System.Windows.Forms.RadioButton()
        Me.btnVote = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblStmntBcn = New System.Windows.Forms.Label()
        Me.ttpMain = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtNumVote = New System.Windows.Forms.TextBox()
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.mnuChoice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuVote = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDesignStmnt = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDesign = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTxtCol = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBckCol = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFont = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAboutUs = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblLine = New System.Windows.Forms.Label()
        Me.dlgColour = New System.Windows.Forms.ColorDialog()
        Me.dlgFont = New System.Windows.Forms.FontDialog()
        Me.btnFont = New System.Windows.Forms.Button()
        Me.btnColour = New System.Windows.Forms.Button()
        Me.btnBckCol = New System.Windows.Forms.Button()
        Me.lblNumVotes = New System.Windows.Forms.Label()
        Me.lblBcnKing = New System.Windows.Forms.Label()
        Me.lblDblCheese = New System.Windows.Forms.Label()
        CType(Me.picDblCheese, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ctxMain.SuspendLayout()
        CType(Me.picBcnKing, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.mnuMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblOrder
        '
        Me.lblOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrder.Location = New System.Drawing.Point(6, 268)
        Me.lblOrder.Name = "lblOrder"
        Me.lblOrder.Size = New System.Drawing.Size(264, 35)
        Me.lblOrder.TabIndex = 1
        Me.lblOrder.Text = "Place your order"
        '
        'lblProduct
        '
        Me.lblProduct.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProduct.Location = New System.Drawing.Point(371, 268)
        Me.lblProduct.Name = "lblProduct"
        Me.lblProduct.Size = New System.Drawing.Size(129, 35)
        Me.lblProduct.TabIndex = 3
        Me.lblProduct.Text = "Product"
        '
        'optBcnKing
        '
        Me.optBcnKing.AutoSize = True
        Me.optBcnKing.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBcnKing.Location = New System.Drawing.Point(348, 412)
        Me.optBcnKing.Name = "optBcnKing"
        Me.optBcnKing.Size = New System.Drawing.Size(202, 32)
        Me.optBcnKing.TabIndex = 4
        Me.optBcnKing.Text = "Bacon King Burger"
        Me.optBcnKing.UseVisualStyleBackColor = True
        '
        'lblVote
        '
        Me.lblVote.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVote.Location = New System.Drawing.Point(680, 268)
        Me.lblVote.Name = "lblVote"
        Me.lblVote.Size = New System.Drawing.Size(95, 35)
        Me.lblVote.TabIndex = 6
        Me.lblVote.Text = "Votes"
        '
        'picDblCheese
        '
        Me.picDblCheese.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picDblCheese.ContextMenuStrip = Me.ctxMain
        Me.picDblCheese.Image = Global.DaxApp_FP_DP_991596313.My.Resources.Resources.THMB_Double_20Cheeseburger_1
        Me.picDblCheese.Location = New System.Drawing.Point(12, 591)
        Me.picDblCheese.Name = "picDblCheese"
        Me.picDblCheese.Size = New System.Drawing.Size(225, 193)
        Me.picDblCheese.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDblCheese.TabIndex = 9
        Me.picDblCheese.TabStop = False
        '
        'ctxMain
        '
        Me.ctxMain.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ctxMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ctxVote, Me.ctxDesignStmnt, Me.ctxSeparator, Me.ctxExit, Me.ctxSeparator2, Me.ctxTxtCol, Me.ctxBckCol, Me.ctxFont})
        Me.ctxMain.Name = "ctxMain"
        Me.ctxMain.Size = New System.Drawing.Size(275, 160)
        '
        'ctxVote
        '
        Me.ctxVote.Name = "ctxVote"
        Me.ctxVote.Size = New System.Drawing.Size(274, 24)
        Me.ctxVote.Text = "Vote Our Product"
        '
        'ctxDesignStmnt
        '
        Me.ctxDesignStmnt.Name = "ctxDesignStmnt"
        Me.ctxDesignStmnt.Size = New System.Drawing.Size(274, 24)
        Me.ctxDesignStmnt.Text = "Design Our Market Statement"
        '
        'ctxSeparator
        '
        Me.ctxSeparator.Name = "ctxSeparator"
        Me.ctxSeparator.Size = New System.Drawing.Size(271, 6)
        '
        'ctxExit
        '
        Me.ctxExit.Name = "ctxExit"
        Me.ctxExit.Size = New System.Drawing.Size(274, 24)
        Me.ctxExit.Text = "Exit"
        '
        'ctxSeparator2
        '
        Me.ctxSeparator2.Name = "ctxSeparator2"
        Me.ctxSeparator2.Size = New System.Drawing.Size(271, 6)
        '
        'ctxTxtCol
        '
        Me.ctxTxtCol.Enabled = False
        Me.ctxTxtCol.Name = "ctxTxtCol"
        Me.ctxTxtCol.Size = New System.Drawing.Size(274, 24)
        Me.ctxTxtCol.Text = "Text Colour"
        '
        'ctxBckCol
        '
        Me.ctxBckCol.Enabled = False
        Me.ctxBckCol.Name = "ctxBckCol"
        Me.ctxBckCol.Size = New System.Drawing.Size(274, 24)
        Me.ctxBckCol.Text = "Background Colour "
        '
        'ctxFont
        '
        Me.ctxFont.Enabled = False
        Me.ctxFont.Name = "ctxFont"
        Me.ctxFont.Size = New System.Drawing.Size(274, 24)
        Me.ctxFont.Text = "Font"
        '
        'picBcnKing
        '
        Me.picBcnKing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picBcnKing.ContextMenuStrip = Me.ctxMain
        Me.picBcnKing.Image = Global.DaxApp_FP_DP_991596313.My.Resources.Resources._02017_75_BK_Web_BACONKING_300x270px_CR1
        Me.picBcnKing.Location = New System.Drawing.Point(12, 338)
        Me.picBcnKing.Name = "picBcnKing"
        Me.picBcnKing.Size = New System.Drawing.Size(225, 193)
        Me.picBcnKing.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBcnKing.TabIndex = 2
        Me.picBcnKing.TabStop = False
        '
        'picIcon
        '
        Me.picIcon.Image = Global.DaxApp_FP_DP_991596313.My.Resources.Resources.honestslogans_burgerking_dribbble
        Me.picIcon.Location = New System.Drawing.Point(12, 43)
        Me.picIcon.Name = "picIcon"
        Me.picIcon.Size = New System.Drawing.Size(264, 157)
        Me.picIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picIcon.TabIndex = 0
        Me.picIcon.TabStop = False
        '
        'optDblCheese
        '
        Me.optDblCheese.AutoSize = True
        Me.optDblCheese.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optDblCheese.Location = New System.Drawing.Point(348, 676)
        Me.optDblCheese.Name = "optDblCheese"
        Me.optDblCheese.Size = New System.Drawing.Size(238, 32)
        Me.optDblCheese.TabIndex = 10
        Me.optDblCheese.Text = "Double Cheese Burger"
        Me.optDblCheese.UseVisualStyleBackColor = True
        '
        'btnVote
        '
        Me.btnVote.BackColor = System.Drawing.Color.Coral
        Me.btnVote.Enabled = False
        Me.btnVote.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVote.ForeColor = System.Drawing.Color.White
        Me.btnVote.Location = New System.Drawing.Point(941, 62)
        Me.btnVote.Name = "btnVote"
        Me.btnVote.Size = New System.Drawing.Size(114, 45)
        Me.btnVote.TabIndex = 13
        Me.btnVote.Text = "Vote"
        Me.ttpMain.SetToolTip(Me.btnVote, "Click here to vote")
        Me.btnVote.UseVisualStyleBackColor = False
        '
        'btnReset
        '
        Me.btnReset.BackColor = System.Drawing.Color.Coral
        Me.btnReset.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ForeColor = System.Drawing.Color.White
        Me.btnReset.Location = New System.Drawing.Point(941, 189)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(114, 45)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Coral
        Me.btnExit.ContextMenuStrip = Me.ctxMain
        Me.btnExit.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.Location = New System.Drawing.Point(941, 312)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(114, 45)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lblStmntBcn
        '
        Me.lblStmntBcn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold)
        Me.lblStmntBcn.Location = New System.Drawing.Point(26, 222)
        Me.lblStmntBcn.Name = "lblStmntBcn"
        Me.lblStmntBcn.Size = New System.Drawing.Size(244, 35)
        Me.lblStmntBcn.TabIndex = 18
        Me.lblStmntBcn.Text = "Eat healthy, live healthy"
        '
        'ttpMain
        '
        Me.ttpMain.Tag = ""
        '
        'txtNumVote
        '
        Me.txtNumVote.Location = New System.Drawing.Point(675, 107)
        Me.txtNumVote.Multiline = True
        Me.txtNumVote.Name = "txtNumVote"
        Me.txtNumVote.Size = New System.Drawing.Size(100, 47)
        Me.txtNumVote.TabIndex = 23
        Me.ttpMain.SetToolTip(Me.txtNumVote, "Enter only number to vote")
        '
        'mnuMain
        '
        Me.mnuMain.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuChoice, Me.mnuDesign, Me.mnuHelp})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(1113, 28)
        Me.mnuMain.TabIndex = 21
        Me.mnuMain.Text = "MenuStrip1"
        '
        'mnuChoice
        '
        Me.mnuChoice.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuVote, Me.mnuDesignStmnt, Me.mnuSeparator, Me.mnuExit})
        Me.mnuChoice.Name = "mnuChoice"
        Me.mnuChoice.Size = New System.Drawing.Size(74, 24)
        Me.mnuChoice.Text = "Choices"
        '
        'mnuVote
        '
        Me.mnuVote.Name = "mnuVote"
        Me.mnuVote.Size = New System.Drawing.Size(288, 26)
        Me.mnuVote.Text = "Vote Our Product"
        '
        'mnuDesignStmnt
        '
        Me.mnuDesignStmnt.Name = "mnuDesignStmnt"
        Me.mnuDesignStmnt.Size = New System.Drawing.Size(288, 26)
        Me.mnuDesignStmnt.Text = "Design Our Market Statement"
        '
        'mnuSeparator
        '
        Me.mnuSeparator.Name = "mnuSeparator"
        Me.mnuSeparator.Size = New System.Drawing.Size(285, 6)
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(288, 26)
        Me.mnuExit.Text = "Exit"
        '
        'mnuDesign
        '
        Me.mnuDesign.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuTxtCol, Me.mnuBckCol, Me.mnuFont})
        Me.mnuDesign.Name = "mnuDesign"
        Me.mnuDesign.Size = New System.Drawing.Size(69, 24)
        Me.mnuDesign.Text = "Design"
        '
        'mnuTxtCol
        '
        Me.mnuTxtCol.Enabled = False
        Me.mnuTxtCol.Name = "mnuTxtCol"
        Me.mnuTxtCol.Size = New System.Drawing.Size(219, 26)
        Me.mnuTxtCol.Text = "Text Colour"
        '
        'mnuBckCol
        '
        Me.mnuBckCol.Enabled = False
        Me.mnuBckCol.Name = "mnuBckCol"
        Me.mnuBckCol.Size = New System.Drawing.Size(219, 26)
        Me.mnuBckCol.Text = "Background Colour"
        '
        'mnuFont
        '
        Me.mnuFont.Enabled = False
        Me.mnuFont.Name = "mnuFont"
        Me.mnuFont.Size = New System.Drawing.Size(219, 26)
        Me.mnuFont.Text = "Font"
        '
        'mnuHelp
        '
        Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAboutUs})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(55, 24)
        Me.mnuHelp.Text = "Help"
        '
        'mnuAboutUs
        '
        Me.mnuAboutUs.Name = "mnuAboutUs"
        Me.mnuAboutUs.Size = New System.Drawing.Size(153, 26)
        Me.mnuAboutUs.Text = "About Us"
        '
        'lblLine
        '
        Me.lblLine.BackColor = System.Drawing.Color.Gray
        Me.lblLine.Location = New System.Drawing.Point(857, 27)
        Me.lblLine.Name = "lblLine"
        Me.lblLine.Size = New System.Drawing.Size(10, 777)
        Me.lblLine.TabIndex = 22
        '
        'btnFont
        '
        Me.btnFont.BackColor = System.Drawing.Color.Coral
        Me.btnFont.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFont.ForeColor = System.Drawing.Color.White
        Me.btnFont.Location = New System.Drawing.Point(941, 450)
        Me.btnFont.Name = "btnFont"
        Me.btnFont.Size = New System.Drawing.Size(114, 45)
        Me.btnFont.TabIndex = 25
        Me.btnFont.Text = "Font"
        Me.btnFont.UseVisualStyleBackColor = False
        '
        'btnColour
        '
        Me.btnColour.BackColor = System.Drawing.Color.Coral
        Me.btnColour.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnColour.ForeColor = System.Drawing.Color.White
        Me.btnColour.Location = New System.Drawing.Point(941, 591)
        Me.btnColour.Name = "btnColour"
        Me.btnColour.Size = New System.Drawing.Size(114, 45)
        Me.btnColour.TabIndex = 26
        Me.btnColour.Text = "Colour"
        Me.btnColour.UseVisualStyleBackColor = False
        '
        'btnBckCol
        '
        Me.btnBckCol.BackColor = System.Drawing.Color.Coral
        Me.btnBckCol.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBckCol.ForeColor = System.Drawing.Color.White
        Me.btnBckCol.Location = New System.Drawing.Point(916, 696)
        Me.btnBckCol.Name = "btnBckCol"
        Me.btnBckCol.Size = New System.Drawing.Size(160, 46)
        Me.btnBckCol.TabIndex = 27
        Me.btnBckCol.Text = "Back Colour"
        Me.btnBckCol.UseVisualStyleBackColor = False
        '
        'lblNumVotes
        '
        Me.lblNumVotes.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumVotes.Location = New System.Drawing.Point(403, 119)
        Me.lblNumVotes.Name = "lblNumVotes"
        Me.lblNumVotes.Size = New System.Drawing.Size(265, 35)
        Me.lblNumVotes.TabIndex = 28
        Me.lblNumVotes.Text = "Number of Votes:"
        '
        'lblBcnKing
        '
        Me.lblBcnKing.ContextMenuStrip = Me.ctxMain
        Me.lblBcnKing.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBcnKing.Location = New System.Drawing.Point(680, 398)
        Me.lblBcnKing.Name = "lblBcnKing"
        Me.lblBcnKing.Size = New System.Drawing.Size(95, 46)
        Me.lblBcnKing.TabIndex = 29
        Me.lblBcnKing.Text = "0"
        Me.lblBcnKing.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDblCheese
        '
        Me.lblDblCheese.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDblCheese.Location = New System.Drawing.Point(680, 665)
        Me.lblDblCheese.Name = "lblDblCheese"
        Me.lblDblCheese.Size = New System.Drawing.Size(95, 51)
        Me.lblDblCheese.TabIndex = 30
        Me.lblDblCheese.Text = "0"
        Me.lblDblCheese.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1113, 813)
        Me.ContextMenuStrip = Me.ctxMain
        Me.Controls.Add(Me.lblDblCheese)
        Me.Controls.Add(Me.lblBcnKing)
        Me.Controls.Add(Me.lblNumVotes)
        Me.Controls.Add(Me.btnBckCol)
        Me.Controls.Add(Me.btnColour)
        Me.Controls.Add(Me.btnFont)
        Me.Controls.Add(Me.txtNumVote)
        Me.Controls.Add(Me.lblLine)
        Me.Controls.Add(Me.lblStmntBcn)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnVote)
        Me.Controls.Add(Me.optDblCheese)
        Me.Controls.Add(Me.picDblCheese)
        Me.Controls.Add(Me.lblVote)
        Me.Controls.Add(Me.optBcnKing)
        Me.Controls.Add(Me.lblProduct)
        Me.Controls.Add(Me.picBcnKing)
        Me.Controls.Add(Me.lblOrder)
        Me.Controls.Add(Me.picIcon)
        Me.Controls.Add(Me.mnuMain)
        Me.MainMenuStrip = Me.mnuMain
        Me.Name = "frmMain"
        Me.Text = "Burger King"
        CType(Me.picDblCheese, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ctxMain.ResumeLayout(False)
        CType(Me.picBcnKing, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picIcon As PictureBox
    Friend WithEvents lblOrder As Label
    Friend WithEvents picBcnKing As PictureBox
    Friend WithEvents lblProduct As Label
    Friend WithEvents optBcnKing As RadioButton
    Friend WithEvents lblVote As Label
    Friend WithEvents picDblCheese As PictureBox
    Friend WithEvents optDblCheese As RadioButton
    Friend WithEvents btnVote As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblStmntBcn As Label
    Friend WithEvents ttpMain As ToolTip
    Friend WithEvents mnuMain As MenuStrip
    Friend WithEvents lblLine As Label
    Friend WithEvents mnuChoice As ToolStripMenuItem
    Friend WithEvents mnuVote As ToolStripMenuItem
    Friend WithEvents mnuDesignStmnt As ToolStripMenuItem
    Friend WithEvents mnuSeparator As ToolStripSeparator
    Friend WithEvents mnuExit As ToolStripMenuItem
    Friend WithEvents mnuDesign As ToolStripMenuItem
    Friend WithEvents mnuTxtCol As ToolStripMenuItem
    Friend WithEvents mnuBckCol As ToolStripMenuItem
    Friend WithEvents mnuFont As ToolStripMenuItem
    Friend WithEvents mnuHelp As ToolStripMenuItem
    Friend WithEvents mnuAboutUs As ToolStripMenuItem
    Friend WithEvents ctxMain As ContextMenuStrip
    Friend WithEvents ctxVote As ToolStripMenuItem
    Friend WithEvents ctxDesignStmnt As ToolStripMenuItem
    Friend WithEvents ctxSeparator As ToolStripSeparator
    Friend WithEvents ctxExit As ToolStripMenuItem
    Friend WithEvents ctxSeparator2 As ToolStripSeparator
    Friend WithEvents ctxTxtCol As ToolStripMenuItem
    Friend WithEvents ctxBckCol As ToolStripMenuItem
    Friend WithEvents ctxFont As ToolStripMenuItem
    Friend WithEvents dlgColour As ColorDialog
    Friend WithEvents dlgFont As FontDialog
    Friend WithEvents txtNumVote As TextBox
    Friend WithEvents btnFont As Button
    Friend WithEvents btnColour As Button
    Friend WithEvents btnBckCol As Button
    Friend WithEvents lblNumVotes As Label
    Friend WithEvents lblBcnKing As Label
    Friend WithEvents lblDblCheese As Label
End Class
