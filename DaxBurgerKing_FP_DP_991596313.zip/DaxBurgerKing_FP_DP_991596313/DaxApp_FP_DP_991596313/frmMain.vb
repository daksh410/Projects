﻿''' <summary>
''' Programmer: Dax Patel
''' Class: PROG18379-2020
''' Final Project
''' </summary>
Public Class frmMain
    ''' <summary>
    ''' User will be able to
    ''' vote product and display message
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnVote_Click(sender As Object, e As EventArgs) Handles btnVote.Click

        Dim EmptyTxtBox As String
        If txtNumVote.Text <> "" Then
            EmptyTxtBox = False
        Else
            EmptyTxtBox = True
        End If

        Select Case EmptyTxtBox
            Case True
                MessageBox.Show("Enter some value to vote", sMessageTitle, MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtNumVote.Text = " "
                txtNumVote.Focus()
            Case False

                Try
                    Dim userChoice As DialogResult
                    userChoice = MessageBox.Show("Are you ready to vote?", sMsgTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Information)

                    iVote = Integer.Parse(txtNumVote.Text)

                    If userChoice = DialogResult.Yes Then

                        If optBcnKing.Checked Then
                            iBcnKing_Total += txtNumVote.Text + 1
                            lblBcnKing.Text = iBcnKing_Total
                        ElseIf optDblCheese.Checked Then
                            iDblCheese_Total += txtNumVote.Text + 1
                            lblDblCheese.Text = iDblCheese_Total
                        Else
                            MessageBox.Show("Select any product to vote", sMessageTitle, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If

                    End If

                Catch ex As Exception

                    MessageBox.Show("Enter valid input to vote", sMessageTitle, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    txtNumVote.Text = " "
                    txtNumVote.Focus()
                End Try

        End Select

    End Sub
    ''' <summary>
    ''' User will exit app and
    ''' message box with total vote 
    ''' for each product will display
    ''' </summary>
    Private Sub ExitApp()
        Dim closeApp As DialogResult
        Dim sMsg As String
        iTtlVote = iBcnKing_Total + iDblCheese_Total
        closeApp = MessageBox.Show("Do you want to exit this app?", sMsgTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Information)

        sMsg = "Bacon King have " & iBcnKing_Total & " Votes" & ControlChars.NewLine & "Double Cheese have " & iDblCheese_Total & " Votes" & ControlChars.NewLine & "Total votes are " & iTtlVote & "."

        If closeApp = DialogResult.Yes Then
            MessageBox.Show(sMsg, sMsgTitle, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Close()
        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ExitApp()
    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        ExitApp()
    End Sub

    Private Sub ctxExit_Click(sender As Object, e As EventArgs) Handles ctxExit.Click
        ExitApp()
    End Sub
    ''' <summary>
    ''' About us message box will appear
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuAboutUs_Click(sender As Object, e As EventArgs) Handles mnuAboutUs.Click
        MessageBox.Show(sMessage, sMsgTitle, MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    ''' <summary>
    ''' User will be able to change font for 
    ''' Market statement
    ''' </summary>
    Private Sub changeFont()
        Dim dFont As DialogResult

        dFont = MessageBox.Show(sFont, sMsgTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If dFont = DialogResult.Yes Then

            dlgFont.ShowDialog()
            lblStmntBcn.Font = dlgFont.Font

        End If

    End Sub

    Private Sub btnFont_Click(sender As Object, e As EventArgs) Handles btnFont.Click
        changeFont()
    End Sub

    Private Sub mnuFont_Click(sender As Object, e As EventArgs) Handles mnuFont.Click
        changeFont()
    End Sub

    Private Sub ctxFont_Click(sender As Object, e As EventArgs) Handles ctxFont.Click
        changeFont()
    End Sub

    ''' <summary>
    ''' User will be able to change 
    ''' font colour of Market Statement
    ''' </summary>
    Private Sub changeColour()
        Dim dColour As DialogResult

        dColour = MessageBox.Show(sColour, sMsgTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If dColour = DialogResult.Yes Then

            dlgColour.ShowDialog()
            lblStmntBcn.ForeColor = dlgColour.Color

        End If
    End Sub

    Private Sub mnuTxtCol_Click(sender As Object, e As EventArgs) Handles mnuTxtCol.Click
        changeColour()
    End Sub

    Private Sub btnColour_Click(sender As Object, e As EventArgs) Handles btnColour.Click
        changeColour()
    End Sub

    Private Sub ctxTxtCol_Click(sender As Object, e As EventArgs) Handles ctxTxtCol.Click
        changeColour()
    End Sub

    ''' <summary>
    ''' User will be able to 
    ''' change back colour of
    ''' Market Satement
    ''' </summary>
    Private Sub BackColour()
        Dim dColour As DialogResult

        dColour = MessageBox.Show(sBckColour, sMsgTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If dColour = DialogResult.Yes Then

            dlgColour.ShowDialog()
            lblStmntBcn.BackColor = dlgColour.Color

        End If
    End Sub

    Private Sub btnBckCol_Click(sender As Object, e As EventArgs) Handles btnBckCol.Click
        BackColour()
    End Sub

    Private Sub mnuBckCol_Click(sender As Object, e As EventArgs) Handles mnuBckCol.Click
        BackColour()
    End Sub

    Private Sub ctxBckCol_Click(sender As Object, e As EventArgs) Handles ctxBckCol.Click
        BackColour()
    End Sub

    ''' <summary>
    ''' Will enable Vote button 
    ''' and design menu sub 
    ''' item for menu and context menu 
    ''' will get disable
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuVote_Click(sender As Object, e As EventArgs) Handles mnuVote.Click
        btnVote.Enabled = True
        mnuTxtCol.Enabled = False
        mnuBckCol.Enabled = False
        mnuFont.Enabled = False
        ctxTxtCol.Enabled = False
        ctxBckCol.Enabled = False
        ctxFont.Enabled = False
    End Sub

    ''' <summary>
    ''' Vote button will get disable 
    ''' and design menu sub for menu and 
    ''' context menu will get enable
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuDesign_Click(sender As Object, e As EventArgs) Handles mnuDesign.Click
        btnVote.Enabled = False
        mnuTxtCol.Enabled = True
        mnuBckCol.Enabled = True
        mnuFont.Enabled = True
        ctxTxtCol.Enabled = True
        ctxBckCol.Enabled = True
        ctxFont.Enabled = True

    End Sub

    ''' <summary>
    ''' Will reset application to startup design
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        btnVote.Enabled = False
        mnuTxtCol.Enabled = False
        mnuBckCol.Enabled = False
        mnuFont.Enabled = False
        ctxTxtCol.Enabled = False
        ctxBckCol.Enabled = False
        ctxFont.Enabled = False
        lblBcnKing.Text = "0"
        lblDblCheese.Text = "0"
        txtNumVote.Text = " "
        lblStmntBcn.ForeColor = Color.Black
        lblStmntBcn.BackColor = Color.White
        txtNumVote.Focus()

    End Sub
End Class


