﻿Module mdlMain
    Public Const iBcnKing As Integer = 1
    Public Const iDblCheese As Integer = 2

    Public iBurger As Integer

    Public sMsgTitle As String = "Burger King"
    Public sMessageTitle As String = "Not able to vote"
    Public sMessage As String = "Burger King is an American multinational chain of" & ControlChars.NewLine & "Cohamburger fast food restaurants. Headquartered in the" & ControlChars.NewLine & "We are famous for Double Whooper and" & ControlChars.NewLine & "large fries, yo must have it"
    Public sColour As String = "Do you want to change" & ControlChars.NewLine & " font colour of lable?"
    Public sFont As String = "Do you want to change" & ControlChars.NewLine & " font of lable?"
    Public sBckColour As String = "Do you want to change" & ControlChars.NewLine & " background colour of lable?"

    Public iBcnKing_Total As Integer
    Public iDblCheese_Total As Integer
    Public iVote As Integer
    Public iTtlVote As Integer
End Module
