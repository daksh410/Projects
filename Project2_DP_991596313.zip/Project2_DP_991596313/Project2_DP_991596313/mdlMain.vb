﻿Module mdlMain
    Public Const sMessage_Title As String = "Bitdefender"
    Public Const sMsg_Title As String = "Having trouble logging in?"
    Public sOutput As String
    Public sFullNm As String
    Public sEmail As String
    Public iPass As Integer
    Public iConfirmPass As Integer
    Public sDfltPass As String = "Password"
    Public sDfltFullNm As String = "Fullname"
    Public sDfltEmail As String = "E-mail Address"
    Public sConfirmPass As String = "Confirm Password"
    Public iInCrrctPass As Integer = 1
End Module
