﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblBitDfnder = New System.Windows.Forms.Label()
        Me.lblCreateAcc = New System.Windows.Forms.Label()
        Me.txtFullNm = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.txtConfirmPass = New System.Windows.Forms.TextBox()
        Me.lblShow = New System.Windows.Forms.Label()
        Me.chkTerms = New System.Windows.Forms.CheckBox()
        Me.lblTermsUses = New System.Windows.Forms.Label()
        Me.btnCreateAcc = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lbPolicy = New System.Windows.Forms.Label()
        Me.lblHaveAcc = New System.Windows.Forms.Label()
        Me.lblSingIn = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblBitDfnder
        '
        Me.lblBitDfnder.AutoSize = True
        Me.lblBitDfnder.Font = New System.Drawing.Font("Calibri", 22.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBitDfnder.Location = New System.Drawing.Point(42, 41)
        Me.lblBitDfnder.Name = "lblBitDfnder"
        Me.lblBitDfnder.Size = New System.Drawing.Size(204, 45)
        Me.lblBitDfnder.TabIndex = 0
        Me.lblBitDfnder.Text = "Bitdefender"
        '
        'lblCreateAcc
        '
        Me.lblCreateAcc.AutoSize = True
        Me.lblCreateAcc.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCreateAcc.ForeColor = System.Drawing.Color.Silver
        Me.lblCreateAcc.Location = New System.Drawing.Point(45, 82)
        Me.lblCreateAcc.Name = "lblCreateAcc"
        Me.lblCreateAcc.Size = New System.Drawing.Size(161, 24)
        Me.lblCreateAcc.TabIndex = 1
        Me.lblCreateAcc.Text = "CREATE ACCOUNT"
        '
        'txtFullNm
        '
        Me.txtFullNm.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFullNm.ForeColor = System.Drawing.Color.Gray
        Me.txtFullNm.Location = New System.Drawing.Point(50, 137)
        Me.txtFullNm.Multiline = True
        Me.txtFullNm.Name = "txtFullNm"
        Me.txtFullNm.Size = New System.Drawing.Size(371, 35)
        Me.txtFullNm.TabIndex = 0
        Me.txtFullNm.Text = "Full Name:"
        '
        'txtEmail
        '
        Me.txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.ForeColor = System.Drawing.Color.Gray
        Me.txtEmail.Location = New System.Drawing.Point(50, 190)
        Me.txtEmail.Multiline = True
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(371, 35)
        Me.txtEmail.TabIndex = 1
        Me.txtEmail.Text = "E-mail address"
        '
        'txtPass
        '
        Me.txtPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPass.ForeColor = System.Drawing.Color.Gray
        Me.txtPass.Location = New System.Drawing.Point(50, 242)
        Me.txtPass.Multiline = True
        Me.txtPass.Name = "txtPass"
        Me.txtPass.Size = New System.Drawing.Size(371, 35)
        Me.txtPass.TabIndex = 2
        Me.txtPass.Text = "Password"
        '
        'txtConfirmPass
        '
        Me.txtConfirmPass.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtConfirmPass.ForeColor = System.Drawing.Color.Gray
        Me.txtConfirmPass.Location = New System.Drawing.Point(50, 293)
        Me.txtConfirmPass.Multiline = True
        Me.txtConfirmPass.Name = "txtConfirmPass"
        Me.txtConfirmPass.Size = New System.Drawing.Size(371, 35)
        Me.txtConfirmPass.TabIndex = 3
        Me.txtConfirmPass.Text = "Confirm Password"
        '
        'lblShow
        '
        Me.lblShow.AutoSize = True
        Me.lblShow.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShow.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblShow.Location = New System.Drawing.Point(363, 245)
        Me.lblShow.Name = "lblShow"
        Me.lblShow.Size = New System.Drawing.Size(48, 21)
        Me.lblShow.TabIndex = 6
        Me.lblShow.Text = "Show"
        '
        'chkTerms
        '
        Me.chkTerms.AutoSize = True
        Me.chkTerms.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkTerms.ForeColor = System.Drawing.Color.Gray
        Me.chkTerms.Location = New System.Drawing.Point(49, 358)
        Me.chkTerms.Name = "chkTerms"
        Me.chkTerms.Size = New System.Drawing.Size(145, 24)
        Me.chkTerms.TabIndex = 7
        Me.chkTerms.Text = "I agree with the"
        Me.chkTerms.UseVisualStyleBackColor = True
        '
        'lblTermsUses
        '
        Me.lblTermsUses.AutoSize = True
        Me.lblTermsUses.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTermsUses.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblTermsUses.Location = New System.Drawing.Point(200, 359)
        Me.lblTermsUses.Name = "lblTermsUses"
        Me.lblTermsUses.Size = New System.Drawing.Size(99, 21)
        Me.lblTermsUses.TabIndex = 8
        Me.lblTermsUses.Text = "Terms of Use"
        '
        'btnCreateAcc
        '
        Me.btnCreateAcc.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCreateAcc.Enabled = False
        Me.btnCreateAcc.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateAcc.ForeColor = System.Drawing.Color.White
        Me.btnCreateAcc.Location = New System.Drawing.Point(49, 415)
        Me.btnCreateAcc.Name = "btnCreateAcc"
        Me.btnCreateAcc.Size = New System.Drawing.Size(372, 39)
        Me.btnCreateAcc.TabIndex = 4
        Me.btnCreateAcc.Text = "Create Account"
        Me.btnCreateAcc.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.White
        Me.btnCancel.Location = New System.Drawing.Point(49, 460)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(372, 39)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.Location = New System.Drawing.Point(49, 505)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(372, 39)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lbPolicy
        '
        Me.lbPolicy.AutoSize = True
        Me.lbPolicy.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbPolicy.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lbPolicy.Location = New System.Drawing.Point(187, 564)
        Me.lbPolicy.Name = "lbPolicy"
        Me.lbPolicy.Size = New System.Drawing.Size(105, 21)
        Me.lbPolicy.TabIndex = 12
        Me.lbPolicy.Text = "Privacy Policy"
        '
        'lblHaveAcc
        '
        Me.lblHaveAcc.AutoSize = True
        Me.lblHaveAcc.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHaveAcc.ForeColor = System.Drawing.Color.Gray
        Me.lblHaveAcc.Location = New System.Drawing.Point(96, 595)
        Me.lblHaveAcc.Name = "lblHaveAcc"
        Me.lblHaveAcc.Size = New System.Drawing.Size(188, 21)
        Me.lblHaveAcc.TabIndex = 13
        Me.lblHaveAcc.Text = "Already have an account?"
        '
        'lblSingIn
        '
        Me.lblSingIn.AutoSize = True
        Me.lblSingIn.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSingIn.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblSingIn.Location = New System.Drawing.Point(281, 595)
        Me.lblSingIn.Name = "lblSingIn"
        Me.lblSingIn.Size = New System.Drawing.Size(56, 21)
        Me.lblSingIn.TabIndex = 14
        Me.lblSingIn.Text = "Sign In"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(491, 637)
        Me.Controls.Add(Me.lblSingIn)
        Me.Controls.Add(Me.lblHaveAcc)
        Me.Controls.Add(Me.lbPolicy)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnCreateAcc)
        Me.Controls.Add(Me.lblTermsUses)
        Me.Controls.Add(Me.chkTerms)
        Me.Controls.Add(Me.lblShow)
        Me.Controls.Add(Me.txtConfirmPass)
        Me.Controls.Add(Me.txtPass)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.txtFullNm)
        Me.Controls.Add(Me.lblCreateAcc)
        Me.Controls.Add(Me.lblBitDfnder)
        Me.Name = "frmMain"
        Me.Text = "BitDefender"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBitDfnder As Label
    Friend WithEvents lblCreateAcc As Label
    Friend WithEvents txtFullNm As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtPass As TextBox
    Friend WithEvents txtConfirmPass As TextBox
    Friend WithEvents lblShow As Label
    Friend WithEvents chkTerms As CheckBox
    Friend WithEvents lblTermsUses As Label
    Friend WithEvents btnCreateAcc As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lbPolicy As Label
    Friend WithEvents lblHaveAcc As Label
    Friend WithEvents lblSingIn As Label
End Class
