﻿''' <summary>
''' Programmer: Dax Patel
''' Date: 03/09/2020
''' Project: Bitdefender
''' </summary>

Public Class frmMain
    ''' <summary>
    ''' Validate user's input and 
    ''' confirm passwords match 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnCreateAcc_Click(sender As Object, e As EventArgs) Handles btnCreateAcc.Click

        Dim EmptyTxtBox As String
        If txtEmail.Text <> "" And txtFullNm.Text <> "" Then
            EmptyTxtBox = False
        Else
            EmptyTxtBox = True
        End If

        Select Case EmptyTxtBox

            Case True
                MessageBox.Show("Please enter valid values", sMsg_Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Case False
                Dim userChoice As DialogResult

                Try
                    iPass = Integer.Parse(txtPass.Text)
                    iConfirmPass = Integer.Parse(txtConfirmPass.Text)

                    If iPass = iConfirmPass Then

                        userChoice = MessageBox.Show("Account created successfully" & ControlChars.NewLine & ControlChars.Tab & "Do you want to exit", sMessage_Title, MessageBoxButtons.YesNo, MessageBoxIcon.Information)
                        If userChoice = DialogResult.Yes Then
                            Me.Close()

                        End If

                    ElseIf iInCrrctPass = 3 Then

                        MessageBox.Show("Failed to Login," & ControlChars.NewLine & "Try again", sMessage_Title, MessageBoxButtons.OK, MessageBoxIcon.Warning)

                    Else

                        iInCrrctPass += 1
                        MessageBox.Show("Not matching Passwords" & ControlChars.NewLine & "Please retry", sMsg_Title, MessageBoxButtons.OK, MessageBoxIcon.Information)

                    End If

                Catch ex As Exception
                    MessageBox.Show("Invalid Input" & ControlChars.NewLine & ControlChars.Tab & "Please enter numbers for Passwords", sMsg_Title, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End Try
        End Select



    End Sub

    ''' <summary>
    ''' Will show message that user
    ''' accepts terms of use
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>

    Private Sub chkTerms_CheckedChanged(sender As Object, e As EventArgs) Handles chkTerms.CheckedChanged


        If chkTerms.Checked Then
            Dim userChoice As DialogResult

            userChoice = MessageBox.Show("You accepted terms of uses of Bitdefender", sMessage_Title, MessageBoxButtons.YesNo, MessageBoxIcon.Information)

            If userChoice = DialogResult.Yes Then
                btnCreateAcc.Enabled = True
            Else
                btnCreateAcc.Enabled = False
                chkTerms.Checked = False
            End If

        End If
    End Sub

    ''' <summary>
    ''' Reset user's input to default
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        txtFullNm.Text = sDfltFullNm
        txtEmail.Text = sDfltEmail
        txtPass.Text = sDfltPass
        txtConfirmPass.Text = sConfirmPass

        btnCreateAcc.Enabled = False
        chkTerms.Checked = False
        txtFullNm.Focus()
    End Sub

    ''' <summary>
    ''' Closes application
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Dim Closeapp As DialogResult
        Closeapp = MessageBox.Show("Are you sure you want to exit this application", sMsg_Title, MessageBoxButtons.YesNo, MessageBoxIcon.Information)

        If Closeapp = DialogResult.Yes Then
            Me.Close()
        End If

    End Sub
End Class
