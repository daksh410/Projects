﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.picAssassinCreed_1 = New System.Windows.Forms.PictureBox()
        Me.lblAssassinCreed_1 = New System.Windows.Forms.Label()
        Me.lblAssassinCreed_2 = New System.Windows.Forms.Label()
        Me.picAssassinCreed_2 = New System.Windows.Forms.PictureBox()
        Me.lblAssassinCreed_3 = New System.Windows.Forms.Label()
        Me.picAssassinCreed_3 = New System.Windows.Forms.PictureBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnResults = New System.Windows.Forms.Button()
        Me.lblTotalNumVoters = New System.Windows.Forms.Label()
        Me.lbltotalNumVotersHeader = New System.Windows.Forms.Label()
        Me.lblNumVotes = New System.Windows.Forms.Label()
        Me.lblPercentageVote = New System.Windows.Forms.Label()
        Me.lblCandidate = New System.Windows.Forms.Label()
        Me.lblRuleAssassinCreed = New System.Windows.Forms.Label()
        Me.optAssassinCreed_1 = New System.Windows.Forms.RadioButton()
        Me.lblPercentageVoteAssassinCreed_1 = New System.Windows.Forms.Label()
        Me.lblNumVoteAssassinCreed_1 = New System.Windows.Forms.Label()
        Me.lblRuleRowTwo = New System.Windows.Forms.Label()
        Me.lblRuleRowOne = New System.Windows.Forms.Label()
        Me.lblNumVoteAssassinCreed_2 = New System.Windows.Forms.Label()
        Me.lblPercentageVoteAssassinCreed_2 = New System.Windows.Forms.Label()
        Me.optAssassinCreed_2 = New System.Windows.Forms.RadioButton()
        Me.lblNumVoteAssassinCreed_3 = New System.Windows.Forms.Label()
        Me.lblPercentageVoteAssassinCreed_3 = New System.Windows.Forms.Label()
        Me.optAssassinCreed_3 = New System.Windows.Forms.RadioButton()
        Me.btnVote = New System.Windows.Forms.Button()
        Me.lblResultWinner = New System.Windows.Forms.Label()
        Me.chkShowGameImg = New System.Windows.Forms.CheckBox()
        CType(Me.picAssassinCreed_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAssassinCreed_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAssassinCreed_3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHeader
        '
        Me.lblHeader.BackColor = System.Drawing.Color.Black
        Me.lblHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.ForeColor = System.Drawing.Color.White
        Me.lblHeader.Location = New System.Drawing.Point(0, 0)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(675, 48)
        Me.lblHeader.TabIndex = 0
        Me.lblHeader.Text = "UBISOFT"
        Me.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Black
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(110, 15)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(497, 20)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "A rich collection of community-produced walkthrough and help videos."
        '
        'picAssassinCreed_1
        '
        Me.picAssassinCreed_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picAssassinCreed_1.Enabled = False
        Me.picAssassinCreed_1.Image = CType(resources.GetObject("picAssassinCreed_1.Image"), System.Drawing.Image)
        Me.picAssassinCreed_1.Location = New System.Drawing.Point(391, 121)
        Me.picAssassinCreed_1.Name = "picAssassinCreed_1"
        Me.picAssassinCreed_1.Size = New System.Drawing.Size(248, 135)
        Me.picAssassinCreed_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picAssassinCreed_1.TabIndex = 2
        Me.picAssassinCreed_1.TabStop = False
        Me.picAssassinCreed_1.Visible = False
        '
        'lblAssassinCreed_1
        '
        Me.lblAssassinCreed_1.AutoSize = True
        Me.lblAssassinCreed_1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAssassinCreed_1.Location = New System.Drawing.Point(387, 268)
        Me.lblAssassinCreed_1.Name = "lblAssassinCreed_1"
        Me.lblAssassinCreed_1.Size = New System.Drawing.Size(157, 20)
        Me.lblAssassinCreed_1.TabIndex = 1
        Me.lblAssassinCreed_1.Text = "Assassing's Creed"
        Me.lblAssassinCreed_1.Visible = False
        '
        'lblAssassinCreed_2
        '
        Me.lblAssassinCreed_2.AutoSize = True
        Me.lblAssassinCreed_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAssassinCreed_2.Location = New System.Drawing.Point(387, 446)
        Me.lblAssassinCreed_2.Name = "lblAssassinCreed_2"
        Me.lblAssassinCreed_2.Size = New System.Drawing.Size(174, 20)
        Me.lblAssassinCreed_2.TabIndex = 1
        Me.lblAssassinCreed_2.Text = "Assassing's Creed II"
        Me.lblAssassinCreed_2.Visible = False
        '
        'picAssassinCreed_2
        '
        Me.picAssassinCreed_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picAssassinCreed_2.Enabled = False
        Me.picAssassinCreed_2.Image = CType(resources.GetObject("picAssassinCreed_2.Image"), System.Drawing.Image)
        Me.picAssassinCreed_2.Location = New System.Drawing.Point(391, 299)
        Me.picAssassinCreed_2.Name = "picAssassinCreed_2"
        Me.picAssassinCreed_2.Size = New System.Drawing.Size(248, 135)
        Me.picAssassinCreed_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picAssassinCreed_2.TabIndex = 2
        Me.picAssassinCreed_2.TabStop = False
        Me.picAssassinCreed_2.Visible = False
        '
        'lblAssassinCreed_3
        '
        Me.lblAssassinCreed_3.AutoSize = True
        Me.lblAssassinCreed_3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAssassinCreed_3.Location = New System.Drawing.Point(387, 624)
        Me.lblAssassinCreed_3.Name = "lblAssassinCreed_3"
        Me.lblAssassinCreed_3.Size = New System.Drawing.Size(180, 20)
        Me.lblAssassinCreed_3.TabIndex = 1
        Me.lblAssassinCreed_3.Text = "Assassing's Creed III"
        Me.lblAssassinCreed_3.Visible = False
        '
        'picAssassinCreed_3
        '
        Me.picAssassinCreed_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picAssassinCreed_3.Enabled = False
        Me.picAssassinCreed_3.Image = CType(resources.GetObject("picAssassinCreed_3.Image"), System.Drawing.Image)
        Me.picAssassinCreed_3.Location = New System.Drawing.Point(391, 477)
        Me.picAssassinCreed_3.Name = "picAssassinCreed_3"
        Me.picAssassinCreed_3.Size = New System.Drawing.Size(248, 135)
        Me.picAssassinCreed_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picAssassinCreed_3.TabIndex = 2
        Me.picAssassinCreed_3.TabStop = False
        Me.picAssassinCreed_3.Visible = False
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.btnExit.Location = New System.Drawing.Point(240, 710)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(125, 29)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.btnReset.Location = New System.Drawing.Point(240, 664)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(125, 29)
        Me.btnReset.TabIndex = 12
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnResults
        '
        Me.btnResults.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.btnResults.Location = New System.Drawing.Point(32, 710)
        Me.btnResults.Name = "btnResults"
        Me.btnResults.Size = New System.Drawing.Size(125, 29)
        Me.btnResults.TabIndex = 13
        Me.btnResults.Text = "Results"
        Me.btnResults.UseVisualStyleBackColor = True
        '
        'lblTotalNumVoters
        '
        Me.lblTotalNumVoters.AutoSize = True
        Me.lblTotalNumVoters.Font = New System.Drawing.Font("Segoe UI", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalNumVoters.ForeColor = System.Drawing.Color.Green
        Me.lblTotalNumVoters.Location = New System.Drawing.Point(511, 698)
        Me.lblTotalNumVoters.Name = "lblTotalNumVoters"
        Me.lblTotalNumVoters.Size = New System.Drawing.Size(38, 45)
        Me.lblTotalNumVoters.TabIndex = 9
        Me.lblTotalNumVoters.Text = "0"
        Me.lblTotalNumVoters.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltotalNumVotersHeader
        '
        Me.lbltotalNumVotersHeader.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltotalNumVotersHeader.Location = New System.Drawing.Point(467, 655)
        Me.lbltotalNumVotersHeader.Name = "lbltotalNumVotersHeader"
        Me.lbltotalNumVotersHeader.Size = New System.Drawing.Size(128, 44)
        Me.lbltotalNumVotersHeader.TabIndex = 10
        Me.lbltotalNumVotersHeader.Text = "Total Number of Voters Voted"
        Me.lbltotalNumVotersHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNumVotes
        '
        Me.lblNumVotes.AutoSize = True
        Me.lblNumVotes.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumVotes.Location = New System.Drawing.Point(16, 82)
        Me.lblNumVotes.Name = "lblNumVotes"
        Me.lblNumVotes.Size = New System.Drawing.Size(113, 17)
        Me.lblNumVotes.TabIndex = 14
        Me.lblNumVotes.Text = "Number of Votes"
        '
        'lblPercentageVote
        '
        Me.lblPercentageVote.AutoSize = True
        Me.lblPercentageVote.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPercentageVote.Location = New System.Drawing.Point(259, 82)
        Me.lblPercentageVote.Name = "lblPercentageVote"
        Me.lblPercentageVote.Size = New System.Drawing.Size(109, 17)
        Me.lblPercentageVote.TabIndex = 15
        Me.lblPercentageVote.Text = "% of Total Votes"
        '
        'lblCandidate
        '
        Me.lblCandidate.AutoSize = True
        Me.lblCandidate.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCandidate.Location = New System.Drawing.Point(152, 82)
        Me.lblCandidate.Name = "lblCandidate"
        Me.lblCandidate.Size = New System.Drawing.Size(36, 17)
        Me.lblCandidate.TabIndex = 16
        Me.lblCandidate.Text = "Title"
        '
        'lblRuleAssassinCreed
        '
        Me.lblRuleAssassinCreed.BackColor = System.Drawing.Color.LightGray
        Me.lblRuleAssassinCreed.Location = New System.Drawing.Point(16, 114)
        Me.lblRuleAssassinCreed.Name = "lblRuleAssassinCreed"
        Me.lblRuleAssassinCreed.Size = New System.Drawing.Size(353, 1)
        Me.lblRuleAssassinCreed.TabIndex = 17
        '
        'optAssassinCreed_1
        '
        Me.optAssassinCreed_1.AutoSize = True
        Me.optAssassinCreed_1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optAssassinCreed_1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optAssassinCreed_1.Location = New System.Drawing.Point(132, 178)
        Me.optAssassinCreed_1.Name = "optAssassinCreed_1"
        Me.optAssassinCreed_1.Size = New System.Drawing.Size(149, 24)
        Me.optAssassinCreed_1.TabIndex = 20
        Me.optAssassinCreed_1.Text = "Assassin's Creed"
        Me.optAssassinCreed_1.UseVisualStyleBackColor = True
        '
        'lblPercentageVoteAssassinCreed_1
        '
        Me.lblPercentageVoteAssassinCreed_1.AutoSize = True
        Me.lblPercentageVoteAssassinCreed_1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPercentageVoteAssassinCreed_1.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblPercentageVoteAssassinCreed_1.Location = New System.Drawing.Point(321, 180)
        Me.lblPercentageVoteAssassinCreed_1.Name = "lblPercentageVoteAssassinCreed_1"
        Me.lblPercentageVoteAssassinCreed_1.Size = New System.Drawing.Size(18, 20)
        Me.lblPercentageVoteAssassinCreed_1.TabIndex = 18
        Me.lblPercentageVoteAssassinCreed_1.Text = "0"
        Me.lblPercentageVoteAssassinCreed_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNumVoteAssassinCreed_1
        '
        Me.lblNumVoteAssassinCreed_1.AutoSize = True
        Me.lblNumVoteAssassinCreed_1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumVoteAssassinCreed_1.Location = New System.Drawing.Point(65, 180)
        Me.lblNumVoteAssassinCreed_1.Name = "lblNumVoteAssassinCreed_1"
        Me.lblNumVoteAssassinCreed_1.Size = New System.Drawing.Size(18, 20)
        Me.lblNumVoteAssassinCreed_1.TabIndex = 19
        Me.lblNumVoteAssassinCreed_1.Text = "0"
        Me.lblNumVoteAssassinCreed_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRuleRowTwo
        '
        Me.lblRuleRowTwo.BackColor = System.Drawing.Color.LightGray
        Me.lblRuleRowTwo.Location = New System.Drawing.Point(12, 465)
        Me.lblRuleRowTwo.Name = "lblRuleRowTwo"
        Me.lblRuleRowTwo.Size = New System.Drawing.Size(353, 1)
        Me.lblRuleRowTwo.TabIndex = 21
        '
        'lblRuleRowOne
        '
        Me.lblRuleRowOne.BackColor = System.Drawing.Color.LightGray
        Me.lblRuleRowOne.Location = New System.Drawing.Point(16, 299)
        Me.lblRuleRowOne.Name = "lblRuleRowOne"
        Me.lblRuleRowOne.Size = New System.Drawing.Size(353, 1)
        Me.lblRuleRowOne.TabIndex = 22
        '
        'lblNumVoteAssassinCreed_2
        '
        Me.lblNumVoteAssassinCreed_2.AutoSize = True
        Me.lblNumVoteAssassinCreed_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumVoteAssassinCreed_2.Location = New System.Drawing.Point(61, 366)
        Me.lblNumVoteAssassinCreed_2.Name = "lblNumVoteAssassinCreed_2"
        Me.lblNumVoteAssassinCreed_2.Size = New System.Drawing.Size(18, 20)
        Me.lblNumVoteAssassinCreed_2.TabIndex = 19
        Me.lblNumVoteAssassinCreed_2.Text = "0"
        Me.lblNumVoteAssassinCreed_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPercentageVoteAssassinCreed_2
        '
        Me.lblPercentageVoteAssassinCreed_2.AutoSize = True
        Me.lblPercentageVoteAssassinCreed_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPercentageVoteAssassinCreed_2.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblPercentageVoteAssassinCreed_2.Location = New System.Drawing.Point(310, 366)
        Me.lblPercentageVoteAssassinCreed_2.Name = "lblPercentageVoteAssassinCreed_2"
        Me.lblPercentageVoteAssassinCreed_2.Size = New System.Drawing.Size(18, 20)
        Me.lblPercentageVoteAssassinCreed_2.TabIndex = 18
        Me.lblPercentageVoteAssassinCreed_2.Text = "0"
        Me.lblPercentageVoteAssassinCreed_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'optAssassinCreed_2
        '
        Me.optAssassinCreed_2.AutoSize = True
        Me.optAssassinCreed_2.Cursor = System.Windows.Forms.Cursors.Default
        Me.optAssassinCreed_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optAssassinCreed_2.Location = New System.Drawing.Point(121, 364)
        Me.optAssassinCreed_2.Name = "optAssassinCreed_2"
        Me.optAssassinCreed_2.Size = New System.Drawing.Size(163, 24)
        Me.optAssassinCreed_2.TabIndex = 20
        Me.optAssassinCreed_2.Text = "Assassin's Creed II"
        Me.optAssassinCreed_2.UseVisualStyleBackColor = True
        '
        'lblNumVoteAssassinCreed_3
        '
        Me.lblNumVoteAssassinCreed_3.AutoSize = True
        Me.lblNumVoteAssassinCreed_3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumVoteAssassinCreed_3.Location = New System.Drawing.Point(61, 542)
        Me.lblNumVoteAssassinCreed_3.Name = "lblNumVoteAssassinCreed_3"
        Me.lblNumVoteAssassinCreed_3.Size = New System.Drawing.Size(18, 20)
        Me.lblNumVoteAssassinCreed_3.TabIndex = 19
        Me.lblNumVoteAssassinCreed_3.Text = "0"
        Me.lblNumVoteAssassinCreed_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPercentageVoteAssassinCreed_3
        '
        Me.lblPercentageVoteAssassinCreed_3.AutoSize = True
        Me.lblPercentageVoteAssassinCreed_3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPercentageVoteAssassinCreed_3.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblPercentageVoteAssassinCreed_3.Location = New System.Drawing.Point(321, 542)
        Me.lblPercentageVoteAssassinCreed_3.Name = "lblPercentageVoteAssassinCreed_3"
        Me.lblPercentageVoteAssassinCreed_3.Size = New System.Drawing.Size(18, 20)
        Me.lblPercentageVoteAssassinCreed_3.TabIndex = 18
        Me.lblPercentageVoteAssassinCreed_3.Text = "0"
        Me.lblPercentageVoteAssassinCreed_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'optAssassinCreed_3
        '
        Me.optAssassinCreed_3.AutoSize = True
        Me.optAssassinCreed_3.Cursor = System.Windows.Forms.Cursors.Default
        Me.optAssassinCreed_3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optAssassinCreed_3.Location = New System.Drawing.Point(132, 540)
        Me.optAssassinCreed_3.Name = "optAssassinCreed_3"
        Me.optAssassinCreed_3.Size = New System.Drawing.Size(168, 24)
        Me.optAssassinCreed_3.TabIndex = 20
        Me.optAssassinCreed_3.Text = "Assassin's Creed III"
        Me.optAssassinCreed_3.UseVisualStyleBackColor = True
        '
        'btnVote
        '
        Me.btnVote.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVote.Location = New System.Drawing.Point(32, 663)
        Me.btnVote.Name = "btnVote"
        Me.btnVote.Size = New System.Drawing.Size(125, 29)
        Me.btnVote.TabIndex = 23
        Me.btnVote.Text = "Click to Vote"
        Me.btnVote.UseVisualStyleBackColor = True
        '
        'lblResultWinner
        '
        Me.lblResultWinner.AutoSize = True
        Me.lblResultWinner.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResultWinner.ForeColor = System.Drawing.Color.Green
        Me.lblResultWinner.Location = New System.Drawing.Point(27, 605)
        Me.lblResultWinner.Name = "lblResultWinner"
        Me.lblResultWinner.Size = New System.Drawing.Size(0, 25)
        Me.lblResultWinner.TabIndex = 24
        Me.lblResultWinner.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkShowGameImg
        '
        Me.chkShowGameImg.AutoSize = True
        Me.chkShowGameImg.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.chkShowGameImg.Location = New System.Drawing.Point(34, 624)
        Me.chkShowGameImg.Name = "chkShowGameImg"
        Me.chkShowGameImg.Size = New System.Drawing.Size(272, 24)
        Me.chkShowGameImg.TabIndex = 25
        Me.chkShowGameImg.Text = "Show All Assassin's Creed Images"
        Me.chkShowGameImg.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(675, 767)
        Me.Controls.Add(Me.chkShowGameImg)
        Me.Controls.Add(Me.lblResultWinner)
        Me.Controls.Add(Me.btnVote)
        Me.Controls.Add(Me.lblRuleRowTwo)
        Me.Controls.Add(Me.lblRuleRowOne)
        Me.Controls.Add(Me.optAssassinCreed_3)
        Me.Controls.Add(Me.lblPercentageVoteAssassinCreed_3)
        Me.Controls.Add(Me.optAssassinCreed_2)
        Me.Controls.Add(Me.lblPercentageVoteAssassinCreed_2)
        Me.Controls.Add(Me.lblNumVoteAssassinCreed_3)
        Me.Controls.Add(Me.optAssassinCreed_1)
        Me.Controls.Add(Me.lblNumVoteAssassinCreed_2)
        Me.Controls.Add(Me.lblPercentageVoteAssassinCreed_1)
        Me.Controls.Add(Me.lblNumVoteAssassinCreed_1)
        Me.Controls.Add(Me.lblRuleAssassinCreed)
        Me.Controls.Add(Me.lblNumVotes)
        Me.Controls.Add(Me.lblPercentageVote)
        Me.Controls.Add(Me.lblCandidate)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnResults)
        Me.Controls.Add(Me.lblTotalNumVoters)
        Me.Controls.Add(Me.lbltotalNumVotersHeader)
        Me.Controls.Add(Me.picAssassinCreed_3)
        Me.Controls.Add(Me.lblAssassinCreed_3)
        Me.Controls.Add(Me.picAssassinCreed_2)
        Me.Controls.Add(Me.lblAssassinCreed_2)
        Me.Controls.Add(Me.picAssassinCreed_1)
        Me.Controls.Add(Me.lblAssassinCreed_1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.lblHeader)
        Me.Name = "frmMain"
        Me.Text = "UBISOFT"
        CType(Me.picAssassinCreed_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAssassinCreed_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAssassinCreed_3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHeader As Label
    Friend WithEvents lblTitle As Label
    Friend WithEvents picAssassinCreed_1 As PictureBox
    Friend WithEvents lblAssassinCreed_1 As Label
    Friend WithEvents lblAssassinCreed_2 As Label
    Friend WithEvents picAssassinCreed_2 As PictureBox
    Friend WithEvents lblAssassinCreed_3 As Label
    Friend WithEvents picAssassinCreed_3 As PictureBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnResults As Button
    Friend WithEvents lblTotalNumVoters As Label
    Friend WithEvents lbltotalNumVotersHeader As Label
    Friend WithEvents lblNumVotes As Label
    Friend WithEvents lblPercentageVote As Label
    Friend WithEvents lblCandidate As Label
    Friend WithEvents lblRuleAssassinCreed As Label
    Friend WithEvents optAssassinCreed_1 As RadioButton
    Friend WithEvents lblPercentageVoteAssassinCreed_1 As Label
    Friend WithEvents lblNumVoteAssassinCreed_1 As Label
    Friend WithEvents lblRuleRowTwo As Label
    Friend WithEvents lblRuleRowOne As Label
    Friend WithEvents lblNumVoteAssassinCreed_2 As Label
    Friend WithEvents lblPercentageVoteAssassinCreed_2 As Label
    Friend WithEvents optAssassinCreed_2 As RadioButton
    Friend WithEvents lblNumVoteAssassinCreed_3 As Label
    Friend WithEvents lblPercentageVoteAssassinCreed_3 As Label
    Friend WithEvents optAssassinCreed_3 As RadioButton
    Friend WithEvents btnVote As Button
    Friend WithEvents lblResultWinner As Label
    Friend WithEvents chkShowGameImg As CheckBox
End Class
