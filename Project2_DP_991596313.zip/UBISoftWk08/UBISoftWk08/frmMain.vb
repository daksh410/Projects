﻿''' <summary>
''' Programmer: Dax Patel
''' Date: 05/03/2020
''' Company: Sheridan College
''' </summary>
Public Class frmMain
    ''' <summary>
    ''' selection for Assassincreed_1. 
    ''' Show image and title of it. 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub optAssassinCreed_1_CheckedChanged(sender As Object, e As EventArgs) Handles optAssassinCreed_1.CheckedChanged
        If picAssassinCreed_1.Visible <> True Then
            picAssassinCreed_1.Visible = True
            picAssassinCreed_2.Visible = False
            picAssassinCreed_3.Visible = False

            lblAssassinCreed_1.Visible = True
            lblAssassinCreed_2.Visible = False
            lblAssassinCreed_3.Visible = False
        End If

        iAssassinCreed_Id = iAssassinCreed_1
    End Sub
    ''' <summary>
    ''' Set profile image to visible, reset all others
    ''' invisible
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub optAssassinCreed_2_CheckedChanged(sender As Object, e As EventArgs) Handles optAssassinCreed_2.CheckedChanged
        If picAssassinCreed_2.Visible <> True Then
            picAssassinCreed_1.Visible = False
            picAssassinCreed_2.Visible = True
            picAssassinCreed_3.Visible = False

            lblAssassinCreed_1.Visible = False
            lblAssassinCreed_2.Visible = True
            lblAssassinCreed_3.Visible = False
        End If

        iAssassinCreed_Id = iAssassinCreed_2
    End Sub
    ''' <summary>
    ''' Set profile image to visible, reset all others
    ''' invisible
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub optAssassinCreed_3_CheckedChanged(sender As Object, e As EventArgs) Handles optAssassinCreed_3.CheckedChanged
        If picAssassinCreed_3.Visible <> True Then
            picAssassinCreed_1.Visible = False
            picAssassinCreed_2.Visible = False
            picAssassinCreed_3.Visible = True

            lblAssassinCreed_1.Visible = False
            lblAssassinCreed_2.Visible = False
            lblAssassinCreed_3.Visible = True
        End If

        iAssassinCreed_Id = iAssassinCreed_3
    End Sub
    ''' <summary>
    ''' Reset All Assassin's profiles
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        optAssassinCreed_1.Checked = False
        optAssassinCreed_2.Checked = False
        optAssassinCreed_3.Checked = False

        picAssassinCreed_1.Visible = False
        picAssassinCreed_2.Visible = False
        picAssassinCreed_3.Visible = False

        lblAssassinCreed_1.Visible = False
        lblAssassinCreed_2.Visible = False
        lblAssassinCreed_3.Visible = False

        iAssassinCreed_Id = 0

        iTotalVote = 0

        iAssassinCreed_1_Total = 0
        iAssassinCreed_2_Total = 0
        iAssassinCreed_3_Total = 0

        lblNumVoteAssassinCreed_1.Text = "0"
        lblNumVoteAssassinCreed_2.Text = "0"
        lblNumVoteAssassinCreed_3.Text = "0"

        lblPercentageVoteAssassinCreed_1.Text = "0"
        lblPercentageVoteAssassinCreed_2.Text = "0"
        lblPercentageVoteAssassinCreed_3.Text = "0"

        lblTotalNumVoters.Text = "0"
        lblResultWinner.Text = " "
    End Sub
    ''' <summary>
    ''' Close app, offer option to continue
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim userChoice As DialogResult

        userChoice = MessageBox.Show("Thank for you for voting," & ControlChars.NewLine & ControlChars.Tab & "are you ready to exit?", sMessageTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If userChoice = DialogResult.Yes Then
            Me.Close()
        Else
            MessageBox.Show("Keeping on voting, total vote is: " & iTotalVote, sMessageTitle, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub btnVote_Click(sender As Object, e As EventArgs) Handles btnVote.Click
        Dim dPercentageVote As Decimal

        Select Case iAssassinCreed_Id
            Case iAssassinCreed_1
                iAssassinCreed_1_Total += 1

                lblNumVoteAssassinCreed_1.Text = iAssassinCreed_1_Total

            Case iAssassinCreed_2
                iAssassinCreed_2_Total += 1

                lblNumVoteAssassinCreed_2.Text = iAssassinCreed_2_Total

            Case iAssassinCreed_3
                iAssassinCreed_3_Total += 1

                lblNumVoteAssassinCreed_3.Text = iAssassinCreed_3_Total
        End Select

        iTotalVote = iAssassinCreed_1_Total + iAssassinCreed_2_Total + iAssassinCreed_3_Total

        If iTotalVote = 0 Then Exit Sub

        dPercentageVote = (iAssassinCreed_1_Total / iTotalVote) * 100

        lblPercentageVoteAssassinCreed_1.Text = dPercentageVote.ToString("N1")

        dPercentageVote = (iAssassinCreed_2_Total / iTotalVote) * 100

        lblPercentageVoteAssassinCreed_2.Text = dPercentageVote.ToString("N1")

        dPercentageVote = (iAssassinCreed_3_Total / iTotalVote) * 100

        lblPercentageVoteAssassinCreed_3.Text = dPercentageVote.ToString("N1")

    End Sub
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnResults_Click(sender As Object, e As EventArgs) Handles btnResults.Click
        iTotalVote = iAssassinCreed_1_Total + iAssassinCreed_2_Total + iAssassinCreed_3_Total
        lblTotalNumVoters.Text = iTotalVote

        If iAssassinCreed_1_Total > iAssassinCreed_2_Total And iAssassinCreed_1_Total > iAssassinCreed_3_Total Then
            lblResultWinner.Text = "Winner is Assassin's Creed!"

        ElseIf iAssassinCreed_2_Total > iAssassinCreed_1_Total And iAssassinCreed_2_Total > iAssassinCreed_3_Total Then
            lblResultWinner.Text = "Winner is Assassin's Creed II!"
        ElseIf iAssassinCreed_3_Total > iAssassinCreed_1_Total And iAssassinCreed_3_Total > iAssassinCreed_2_Total Then
            lblResultWinner.Text = "Winner is Assassin's Creed III!"
        Else
            lblResultWinner.Text = "Keep Voting UBISOFT polling is open!"
        End If
    End Sub

    Private Sub chkShowGameImg_CheckStateChanged(sender As Object, e As EventArgs) Handles chkShowGameImg.CheckStateChanged
        If chkShowGameImg.Checked Then
            picAssassinCreed_1.Visible = True
            picAssassinCreed_2.Visible = True
            picAssassinCreed_3.Visible = True

            lblAssassinCreed_1.Visible = True
            lblAssassinCreed_2.Visible = True
            lblAssassinCreed_3.Visible = True
        Else
            picAssassinCreed_1.Visible = False
            picAssassinCreed_2.Visible = False
            picAssassinCreed_3.Visible = False

            lblAssassinCreed_1.Visible = False
            lblAssassinCreed_2.Visible = False
            lblAssassinCreed_3.Visible = False
        End If
    End Sub
End Class
