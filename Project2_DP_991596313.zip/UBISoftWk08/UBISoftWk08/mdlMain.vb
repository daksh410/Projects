﻿Module mdlMain
    Public iTotalVote As Integer
    Public Const iAssassinCreed_1 As Integer = 1
    Public Const iAssassinCreed_2 As Integer = 2
    Public Const iAssassinCreed_3 As Integer = 3

    Public iAssassinCreed_Id As Integer
    Public iAssassinCreed_1_Total As Integer
    Public iAssassinCreed_2_Total As Integer
    Public iAssassinCreed_3_Total As Integer

    Public dResultPercentage As Decimal

    Public sVotingMessage As String

    Public sMessageTitle As String = "UBISOFT Assassin Creed Voting"


End Module
