﻿''' <summary>
''' Name: Dax Patel
''' Subject: VB.NET Programming
''' Mid-Term Exam
''' Date: 20/02/2020
''' </summary>
Public Class frmMain
    ''' <summary>
    ''' Luxury and Specialty buttons will not be 
    ''' enabled and it will show a message of using your 
    ''' email as username
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub chkUserNm_CheckedChanged(sender As Object, e As EventArgs) Handles chkUserNm.CheckedChanged
        btnSpecialty.Enabled = True
        btnLuxury.Enabled = True

        MessageBox.Show("AVIS will allow using email as Username.", sMESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub
    ''' <summary>
    ''' Image of Challenger will be shown
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnSpecialty_Click(sender As Object, e As EventArgs) Handles btnSpecialty.Click
        lblDodge.Visible = True
        pbxDodge.Visible = True
    End Sub
    ''' <summary>
    ''' Image of Chysler 300S will be shown
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnLuxury_Click(sender As Object, e As EventArgs) Handles btnLuxury.Click
        lblDodge.Visible = False
        pbxDodge.Visible = False
        lblChrysler.Visible = True
        pbxChrysler.Visible = True
    End Sub
    ''' <summary>
    ''' It will show a message box about information of AWD Number
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        Try
            Dim sMsg As String
            sFstNm = txtFstNm.Text
            sLstNm = txtLstNm.Text
            iAWDNum = Integer.Parse(txtAWDNum.Text)

            sMsg = " " & sFstNm & " " & sLstNm & ", Please use your sign-on account for this AWD number:" & iAWDNum & "."
            MessageBox.Show(sMsg, sMESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Invalid AWD number, rechech input!", sMESSAGE_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try



    End Sub
    ''' <summary>
    ''' Clears all input Data and set focus on AWD Number textbox
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        txtAWDNum.Text = " "
        txtEmail.Text = " "
        txtFstNm.Text = " "
        txtLstNm.Text = " "
        txtPass.Text = " "
        txtAWDNum.Focus()

        btnLuxury.Enabled = False
        btnSpecialty.Enabled = False
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
