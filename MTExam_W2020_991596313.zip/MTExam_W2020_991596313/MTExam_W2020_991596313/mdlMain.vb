﻿Module mdlMain
    Public Const sMESSAGE_TITLE As String = "AVIS Car Rental"
    Public iAWDNum As Integer
    Public sFstNm As String
    Public sLstNm As String
    Public sEmail As String
    Public iPass As Integer
End Module
