﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.lblShade = New System.Windows.Forms.Label()
        Me.lblAvis = New System.Windows.Forms.Label()
        Me.lblCanada = New System.Windows.Forms.Label()
        Me.lblJoin = New System.Windows.Forms.Label()
        Me.lblsetup = New System.Windows.Forms.Label()
        Me.lblLine = New System.Windows.Forms.Label()
        Me.lblWizard = New System.Windows.Forms.Label()
        Me.lblAWDNum = New System.Windows.Forms.Label()
        Me.txtAWDNum = New System.Windows.Forms.TextBox()
        Me.lblFstNm = New System.Windows.Forms.Label()
        Me.txtFstNm = New System.Windows.Forms.TextBox()
        Me.lblLstNm = New System.Windows.Forms.Label()
        Me.txtLstNm = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblPass = New System.Windows.Forms.Label()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.chkUserNm = New System.Windows.Forms.CheckBox()
        Me.lblLine2 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.btnSpecialty = New System.Windows.Forms.Button()
        Me.btnLuxury = New System.Windows.Forms.Button()
        Me.lblDodge = New System.Windows.Forms.Label()
        Me.pbxDodge = New System.Windows.Forms.PictureBox()
        Me.pbxChrysler = New System.Windows.Forms.PictureBox()
        Me.lblChrysler = New System.Windows.Forms.Label()
        CType(Me.pbxDodge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxChrysler, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblShade
        '
        Me.lblShade.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.lblShade.Location = New System.Drawing.Point(1, 0)
        Me.lblShade.Name = "lblShade"
        Me.lblShade.Size = New System.Drawing.Size(800, 69)
        Me.lblShade.TabIndex = 0
        '
        'lblAvis
        '
        Me.lblAvis.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.lblAvis.Font = New System.Drawing.Font("Calibri", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvis.ForeColor = System.Drawing.Color.Red
        Me.lblAvis.Location = New System.Drawing.Point(25, 19)
        Me.lblAvis.Name = "lblAvis"
        Me.lblAvis.Size = New System.Drawing.Size(62, 27)
        Me.lblAvis.TabIndex = 1
        Me.lblAvis.Text = "AVIS"
        '
        'lblCanada
        '
        Me.lblCanada.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.lblCanada.Font = New System.Drawing.Font("Calibri", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCanada.ForeColor = System.Drawing.Color.Red
        Me.lblCanada.Location = New System.Drawing.Point(93, 29)
        Me.lblCanada.Name = "lblCanada"
        Me.lblCanada.Size = New System.Drawing.Size(77, 17)
        Me.lblCanada.TabIndex = 2
        Me.lblCanada.Text = "Canada"
        '
        'lblJoin
        '
        Me.lblJoin.BackColor = System.Drawing.SystemColors.Window
        Me.lblJoin.Font = New System.Drawing.Font("Calibri", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJoin.ForeColor = System.Drawing.Color.Black
        Me.lblJoin.Location = New System.Drawing.Point(25, 91)
        Me.lblJoin.Name = "lblJoin"
        Me.lblJoin.Size = New System.Drawing.Size(191, 27)
        Me.lblJoin.TabIndex = 3
        Me.lblJoin.Text = "Join Avis Preferred"
        '
        'lblsetup
        '
        Me.lblsetup.BackColor = System.Drawing.SystemColors.Window
        Me.lblsetup.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsetup.ForeColor = System.Drawing.Color.Black
        Me.lblsetup.Location = New System.Drawing.Point(27, 118)
        Me.lblsetup.Name = "lblsetup"
        Me.lblsetup.Size = New System.Drawing.Size(324, 18)
        Me.lblsetup.TabIndex = 4
        Me.lblsetup.Text = "Let's get your personal account set up."
        '
        'lblLine
        '
        Me.lblLine.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.lblLine.Location = New System.Drawing.Point(26, 146)
        Me.lblLine.Name = "lblLine"
        Me.lblLine.Size = New System.Drawing.Size(740, 2)
        Me.lblLine.TabIndex = 5
        '
        'lblWizard
        '
        Me.lblWizard.BackColor = System.Drawing.SystemColors.Window
        Me.lblWizard.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWizard.ForeColor = System.Drawing.Color.Red
        Me.lblWizard.Location = New System.Drawing.Point(26, 158)
        Me.lblWizard.Name = "lblWizard"
        Me.lblWizard.Size = New System.Drawing.Size(421, 17)
        Me.lblWizard.TabIndex = 6
        Me.lblWizard.Text = "Do you already have a 6-digit Avis Wizard Number? Start Here"
        '
        'lblAWDNum
        '
        Me.lblAWDNum.BackColor = System.Drawing.SystemColors.Window
        Me.lblAWDNum.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAWDNum.ForeColor = System.Drawing.Color.Black
        Me.lblAWDNum.Location = New System.Drawing.Point(25, 193)
        Me.lblAWDNum.Name = "lblAWDNum"
        Me.lblAWDNum.Size = New System.Drawing.Size(160, 18)
        Me.lblAWDNum.TabIndex = 7
        Me.lblAWDNum.Text = "AWD Number"
        '
        'txtAWDNum
        '
        Me.txtAWDNum.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.txtAWDNum.Location = New System.Drawing.Point(29, 214)
        Me.txtAWDNum.Name = "txtAWDNum"
        Me.txtAWDNum.Size = New System.Drawing.Size(141, 22)
        Me.txtAWDNum.TabIndex = 0
        '
        'lblFstNm
        '
        Me.lblFstNm.BackColor = System.Drawing.SystemColors.Window
        Me.lblFstNm.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFstNm.ForeColor = System.Drawing.Color.Black
        Me.lblFstNm.Location = New System.Drawing.Point(25, 248)
        Me.lblFstNm.Name = "lblFstNm"
        Me.lblFstNm.Size = New System.Drawing.Size(160, 18)
        Me.lblFstNm.TabIndex = 0
        Me.lblFstNm.Text = "First Name"
        '
        'txtFstNm
        '
        Me.txtFstNm.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.txtFstNm.Location = New System.Drawing.Point(29, 269)
        Me.txtFstNm.Name = "txtFstNm"
        Me.txtFstNm.Size = New System.Drawing.Size(279, 22)
        Me.txtFstNm.TabIndex = 1
        '
        'lblLstNm
        '
        Me.lblLstNm.BackColor = System.Drawing.SystemColors.Window
        Me.lblLstNm.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLstNm.ForeColor = System.Drawing.Color.Black
        Me.lblLstNm.Location = New System.Drawing.Point(26, 306)
        Me.lblLstNm.Name = "lblLstNm"
        Me.lblLstNm.Size = New System.Drawing.Size(160, 18)
        Me.lblLstNm.TabIndex = 11
        Me.lblLstNm.Text = "Last Name"
        '
        'txtLstNm
        '
        Me.txtLstNm.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.txtLstNm.Location = New System.Drawing.Point(29, 327)
        Me.txtLstNm.Name = "txtLstNm"
        Me.txtLstNm.Size = New System.Drawing.Size(279, 22)
        Me.txtLstNm.TabIndex = 2
        '
        'lblEmail
        '
        Me.lblEmail.BackColor = System.Drawing.SystemColors.Window
        Me.lblEmail.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.ForeColor = System.Drawing.Color.Black
        Me.lblEmail.Location = New System.Drawing.Point(26, 363)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(160, 18)
        Me.lblEmail.TabIndex = 13
        Me.lblEmail.Text = "Email Address"
        '
        'txtEmail
        '
        Me.txtEmail.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.txtEmail.Location = New System.Drawing.Point(29, 384)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(279, 22)
        Me.txtEmail.TabIndex = 3
        '
        'lblPass
        '
        Me.lblPass.BackColor = System.Drawing.SystemColors.Window
        Me.lblPass.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPass.ForeColor = System.Drawing.Color.Black
        Me.lblPass.Location = New System.Drawing.Point(26, 419)
        Me.lblPass.Name = "lblPass"
        Me.lblPass.Size = New System.Drawing.Size(239, 18)
        Me.lblPass.TabIndex = 15
        Me.lblPass.Text = "Password(numbers only!)"
        '
        'txtPass
        '
        Me.txtPass.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.txtPass.Location = New System.Drawing.Point(29, 440)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.Size = New System.Drawing.Size(116, 22)
        Me.txtPass.TabIndex = 4
        '
        'chkUserNm
        '
        Me.chkUserNm.Location = New System.Drawing.Point(29, 480)
        Me.chkUserNm.Name = "chkUserNm"
        Me.chkUserNm.Size = New System.Drawing.Size(267, 21)
        Me.chkUserNm.TabIndex = 17
        Me.chkUserNm.Text = "Use Email address as Username"
        Me.chkUserNm.UseVisualStyleBackColor = True
        '
        'lblLine2
        '
        Me.lblLine2.BackColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.lblLine2.Location = New System.Drawing.Point(26, 520)
        Me.lblLine2.Name = "lblLine2"
        Me.lblLine2.Size = New System.Drawing.Size(740, 2)
        Me.lblLine2.TabIndex = 18
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(29, 543)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 28)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(276, 543)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 28)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnCreate
        '
        Me.btnCreate.BackColor = System.Drawing.Color.Red
        Me.btnCreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreate.ForeColor = System.Drawing.Color.White
        Me.btnCreate.Location = New System.Drawing.Point(703, 543)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(75, 28)
        Me.btnCreate.TabIndex = 9
        Me.btnCreate.Text = "Create"
        Me.btnCreate.UseVisualStyleBackColor = False
        '
        'btnSpecialty
        '
        Me.btnSpecialty.BackColor = System.Drawing.Color.Red
        Me.btnSpecialty.Enabled = False
        Me.btnSpecialty.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSpecialty.ForeColor = System.Drawing.Color.White
        Me.btnSpecialty.Location = New System.Drawing.Point(348, 434)
        Me.btnSpecialty.Name = "btnSpecialty"
        Me.btnSpecialty.Size = New System.Drawing.Size(99, 28)
        Me.btnSpecialty.TabIndex = 7
        Me.btnSpecialty.Text = "Specialty"
        Me.btnSpecialty.UseVisualStyleBackColor = False
        '
        'btnLuxury
        '
        Me.btnLuxury.BackColor = System.Drawing.Color.Red
        Me.btnLuxury.Enabled = False
        Me.btnLuxury.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLuxury.ForeColor = System.Drawing.Color.White
        Me.btnLuxury.Location = New System.Drawing.Point(639, 437)
        Me.btnLuxury.Name = "btnLuxury"
        Me.btnLuxury.Size = New System.Drawing.Size(88, 28)
        Me.btnLuxury.TabIndex = 8
        Me.btnLuxury.Text = "Luxury"
        Me.btnLuxury.UseVisualStyleBackColor = False
        '
        'lblDodge
        '
        Me.lblDodge.BackColor = System.Drawing.SystemColors.Window
        Me.lblDodge.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDodge.ForeColor = System.Drawing.Color.Black
        Me.lblDodge.Location = New System.Drawing.Point(344, 193)
        Me.lblDodge.Name = "lblDodge"
        Me.lblDodge.Size = New System.Drawing.Size(160, 25)
        Me.lblDodge.TabIndex = 24
        Me.lblDodge.Text = "Dodge Challenger"
        Me.lblDodge.Visible = False
        '
        'pbxDodge
        '
        Me.pbxDodge.Image = CType(resources.GetObject("pbxDodge.Image"), System.Drawing.Image)
        Me.pbxDodge.Location = New System.Drawing.Point(348, 215)
        Me.pbxDodge.Name = "pbxDodge"
        Me.pbxDodge.Size = New System.Drawing.Size(366, 199)
        Me.pbxDodge.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxDodge.TabIndex = 25
        Me.pbxDodge.TabStop = False
        Me.pbxDodge.Visible = False
        '
        'pbxChrysler
        '
        Me.pbxChrysler.Image = CType(resources.GetObject("pbxChrysler.Image"), System.Drawing.Image)
        Me.pbxChrysler.Location = New System.Drawing.Point(348, 215)
        Me.pbxChrysler.Name = "pbxChrysler"
        Me.pbxChrysler.Size = New System.Drawing.Size(366, 199)
        Me.pbxChrysler.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxChrysler.TabIndex = 26
        Me.pbxChrysler.TabStop = False
        Me.pbxChrysler.Visible = False
        '
        'lblChrysler
        '
        Me.lblChrysler.BackColor = System.Drawing.SystemColors.Window
        Me.lblChrysler.Font = New System.Drawing.Font("Calibri", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChrysler.ForeColor = System.Drawing.Color.Black
        Me.lblChrysler.Location = New System.Drawing.Point(344, 193)
        Me.lblChrysler.Name = "lblChrysler"
        Me.lblChrysler.Size = New System.Drawing.Size(160, 25)
        Me.lblChrysler.TabIndex = 27
        Me.lblChrysler.Text = "Chrysler 300S"
        Me.lblChrysler.Visible = False
        '
        'frmMain
        '
        Me.AcceptButton = Me.btnExit
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(800, 611)
        Me.Controls.Add(Me.pbxDodge)
        Me.Controls.Add(Me.lblDodge)
        Me.Controls.Add(Me.btnLuxury)
        Me.Controls.Add(Me.btnSpecialty)
        Me.Controls.Add(Me.btnCreate)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.lblLine2)
        Me.Controls.Add(Me.chkUserNm)
        Me.Controls.Add(Me.txtPass)
        Me.Controls.Add(Me.lblPass)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.txtLstNm)
        Me.Controls.Add(Me.lblLstNm)
        Me.Controls.Add(Me.txtFstNm)
        Me.Controls.Add(Me.lblFstNm)
        Me.Controls.Add(Me.txtAWDNum)
        Me.Controls.Add(Me.lblAWDNum)
        Me.Controls.Add(Me.lblWizard)
        Me.Controls.Add(Me.lblLine)
        Me.Controls.Add(Me.lblsetup)
        Me.Controls.Add(Me.lblJoin)
        Me.Controls.Add(Me.lblCanada)
        Me.Controls.Add(Me.lblAvis)
        Me.Controls.Add(Me.lblShade)
        Me.Controls.Add(Me.pbxChrysler)
        Me.Controls.Add(Me.lblChrysler)
        Me.Name = "frmMain"
        Me.Text = "Avis Car Rental"
        CType(Me.pbxDodge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxChrysler, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblShade As Label
    Friend WithEvents lblAvis As Label
    Friend WithEvents lblCanada As Label
    Friend WithEvents lblJoin As Label
    Friend WithEvents lblsetup As Label
    Friend WithEvents lblLine As Label
    Friend WithEvents lblWizard As Label
    Friend WithEvents lblAWDNum As Label
    Friend WithEvents txtAWDNum As TextBox
    Friend WithEvents lblFstNm As Label
    Friend WithEvents txtFstNm As TextBox
    Friend WithEvents lblLstNm As Label
    Friend WithEvents txtLstNm As TextBox
    Friend WithEvents lblEmail As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents lblPass As Label
    Friend WithEvents txtPass As TextBox
    Friend WithEvents chkUserNm As CheckBox
    Friend WithEvents lblLine2 As Label
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnCreate As Button
    Friend WithEvents btnSpecialty As Button
    Friend WithEvents btnLuxury As Button
    Friend WithEvents lblDodge As Label
    Friend WithEvents pbxDodge As PictureBox
    Friend WithEvents pbxChrysler As PictureBox
    Friend WithEvents lblChrysler As Label
End Class
